package com.example

import com.example.model.SosPacket
import com.example.model.TriageBitmaskHelper
import com.example.model.TriageFlag
import com.example.serializer.PacketSerializer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun `packet serialization produces exact 30 bytes`() {
        val selectedFlags = setOf(
            TriageFlag.DROWNING,
            TriageFlag.TRAPPED,
            TriageFlag.MEDICINE_INSULIN,
            TriageFlag.FOOD_WATER
        )
        val bitmask = TriageBitmaskHelper.toBitmask(selectedFlags)

        val original = SosPacket(
            protocolVersion = SosPacket.PROTOCOL_SOS,
            packetHash = 0x123456789ABCDEF0L,
            latitude = 37.7749f,
            longitude = -122.4194f,
            triageFlags = bitmask,
            headcount = 3,
            batteryPercent = 85,
            ttl = 5,
            timestampSeconds = 1700000000L
        )

        val bytes = PacketSerializer.serialize(original)
        assertEquals(30, bytes.size)

        val unpacked = PacketSerializer.deserialize(bytes)
        assertNotNull(unpacked)
        assertEquals(SosPacket.PROTOCOL_SOS, unpacked!!.protocolVersion)
        assertEquals(0x123456789ABCDEF0L, unpacked.packetHash)
        assertEquals(37.7749f, unpacked.latitude, 0.0001f)
        assertEquals(-122.4194f, unpacked.longitude, 0.0001f)
        assertEquals(bitmask, unpacked.triageFlags)
        assertTrue(unpacked.hasFlag(TriageFlag.DROWNING))
        assertTrue(unpacked.hasFlag(TriageFlag.TRAPPED))
        assertTrue(unpacked.hasFlag(TriageFlag.MEDICINE_INSULIN))
        assertTrue(unpacked.hasFlag(TriageFlag.FOOD_WATER))
        assertEquals(3, unpacked.headcount)
        assertEquals(5.toByte(), unpacked.ttl)
    }

    @Test
    fun `all 9 triage flags bitmask correctly packed and unpacked`() {
        val allFlags = TriageFlag.entries.toSet()
        val bitmask = TriageBitmaskHelper.toBitmask(allFlags)
        val recovered = TriageBitmaskHelper.fromBitmask(bitmask)

        assertEquals(9, recovered.size)
        allFlags.forEach { flag ->
            assertTrue(recovered.contains(flag))
        }
    }

    @Test
    fun `wake siren packet generation and verification`() {
        val wakeBytes = PacketSerializer.createWakeSirenPacket(0x1988776655443322L)
        assertEquals(30, wakeBytes.size)

        val unpacked = PacketSerializer.deserialize(wakeBytes)
        assertNotNull(unpacked)
        assertEquals(SosPacket.PROTOCOL_WAKE_SIREN, unpacked!!.protocolVersion)
    }

    @Test
    fun `tampered bytes reject deserialization`() {
        val original = SosPacket(
            protocolVersion = SosPacket.PROTOCOL_SOS,
            packetHash = 0x5555555555555555L,
            latitude = 12.34f,
            longitude = 56.78f,
            triageFlags = 0,
            headcount = 1,
            batteryPercent = 50,
            ttl = 5,
            timestampSeconds = 1700000000L
        )
        val bytes = PacketSerializer.serialize(original)
        // Corrupt a byte in the payload
        bytes[10] = (bytes[10].toInt() xor 0xFF).toByte()

        val unpacked = PacketSerializer.deserialize(bytes)
        assertNull(unpacked)
    }
}
