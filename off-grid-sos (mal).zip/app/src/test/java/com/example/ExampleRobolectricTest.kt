package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.CachedPacketEntity
import com.example.data.EmergencyDatabase
import com.example.data.EmergencyEntity
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private lateinit var db: EmergencyDatabase

    @Before
    fun createDb() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, EmergencyDatabase::class.java)
            .allowMainThreadQueries()
            .build()
    }

    @After
    fun closeDb() {
        db.close()
    }

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Off-Grid SOS", appName)
    }

    @Test
    fun `room database ring buffer insertion and retrieval`() = runBlocking {
        val dao = db.packetDao()
        val testHash = 0x1BCDEF1234567890L
        val entity = CachedPacketEntity(
            packetHash = testHash,
            protocolVersion = 1,
            latitude = 40.7128f,
            longitude = -74.0060f,
            triageFlags = 0x05,
            headcount = 2,
            batteryPercent = 90,
            ttl = 5,
            timestampSeconds = 1700000000L,
            isSelfCreated = true,
            rawBytes = ByteArray(30)
        )

        dao.insertPacket(entity)
        val count = dao.countByHash(testHash)
        assertEquals(1, count)

        val queue = dao.getRelayQueue()
        assertEquals(1, queue.size)
        assertEquals(testHash, queue[0].packetHash)
    }

    @Test
    fun `emergency alert dao workflow - pending delivery, update note, and status`() = runBlocking {
        val emergencyDao = db.emergencyDao()
        val testHash = 0x7777888899990000L
        val alert = EmergencyEntity(
            packetHash = testHash,
            protocolVersion = 1,
            latitude = 34.0522f,
            longitude = -118.2437f,
            triageBitmask = 0x01FF, // All 9 flags
            headcount = 4,
            batteryPercent = 75,
            ttl = 5,
            timestampSeconds = 1700000000L,
            status = EmergencyEntity.STATUS_PENDING_DELIVERY,
            customNote = "",
            rawBytes = ByteArray(30),
            isSelfCreated = true
        )

        emergencyDao.insertAlert(alert)
        val count = emergencyDao.countByHash(testHash)
        assertEquals(1, count)

        val retrieved = emergencyDao.getAlertByHash(testHash)
        assertNotNull(retrieved)
        assertEquals(EmergencyEntity.STATUS_PENDING_DELIVERY, retrieved!!.status)
        assertEquals("", retrieved.customNote)

        // Update note dynamically
        val newRaw = ByteArray(30) { 0x02 }
        emergencyDao.updateMessageAndPayload(testHash, "3rd Floor North Stairwell", newRaw)
        val updated = emergencyDao.getAlertByHash(testHash)
        assertEquals("3rd Floor North Stairwell", updated?.customNote)

        // Update status to DELIVERED
        emergencyDao.updateStatus(testHash, EmergencyEntity.STATUS_DELIVERED)
        val delivered = emergencyDao.getAlertByHash(testHash)
        assertEquals(EmergencyEntity.STATUS_DELIVERED, delivered?.status)
    }
}
