package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Room Database entity representing emergency alerts (both local SOS and relayed mesh packets).
 */
@Entity(tableName = "emergency_alerts")
data class EmergencyEntity(
    @PrimaryKey val packetHash: Long,
    val protocolVersion: Int = 1,
    val latitude: Float,
    val longitude: Float,
    val triageBitmask: Int, // 16-bit bitmask stored as Int (Bytes 17-18)
    val headcount: Int = 1,
    val batteryPercent: Int = 100,
    val ttl: Int = 5,
    val timestampSeconds: Long,
    val status: String = STATUS_PENDING_DELIVERY,
    val customNote: String = "",
    val rawBytes: ByteArray,
    val isSelfCreated: Boolean = true,
    val relayCount: Int = 0,
    val createdAtMillis: Long = System.currentTimeMillis(),
    val updatedAtMillis: Long = System.currentTimeMillis()
) {
    companion object {
        const val STATUS_PENDING_DELIVERY = "PENDING_DELIVERY"
        const val STATUS_ACTIVE_BROADCASTING = "ACTIVE_BROADCASTING"
        const val STATUS_DELIVERED = "DELIVERED"
        const val STATUS_RESOLVED = "RESOLVED"
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false
        other as EmergencyEntity
        return packetHash == other.packetHash
    }

    override fun hashCode(): Int {
        return packetHash.hashCode()
    }
}
