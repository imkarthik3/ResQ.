package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface EmergencyPacketDao {

    @Query("SELECT * FROM cached_packets ORDER BY receivedAtMillis DESC")
    fun getAllPacketsFlow(): Flow<List<CachedPacketEntity>>

    @Query("SELECT * FROM cached_packets WHERE ttl > 0 ORDER BY receivedAtMillis DESC LIMIT 50")
    suspend fun getRelayQueue(): List<CachedPacketEntity>

    @Query("SELECT COUNT(*) FROM cached_packets WHERE packetHash = :hash")
    suspend fun countByHash(hash: Long): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPacket(packet: CachedPacketEntity)

    @Query("UPDATE cached_packets SET relayCount = relayCount + 1, ttl = CASE WHEN ttl > 1 THEN ttl - 1 ELSE 0 END WHERE packetHash = :hash")
    suspend fun recordRelay(hash: Long)

    @Query("DELETE FROM cached_packets WHERE packetHash NOT IN (SELECT packetHash FROM cached_packets ORDER BY receivedAtMillis DESC LIMIT :maxEntries)")
    suspend fun pruneOldRingBuffer(maxEntries: Int = 100)

    @Query("DELETE FROM cached_packets WHERE packetHash = :hash")
    suspend fun deleteByHash(hash: Long)

    @Query("DELETE FROM cached_packets")
    suspend fun clearAll()
}
