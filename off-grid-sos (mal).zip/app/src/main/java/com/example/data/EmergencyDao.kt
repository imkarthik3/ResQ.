package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface EmergencyDao {

    @Query("SELECT * FROM emergency_alerts ORDER BY createdAtMillis DESC")
    fun getAllAlertsFlow(): Flow<List<EmergencyEntity>>

    @Query("SELECT * FROM emergency_alerts WHERE packetHash = :hash LIMIT 1")
    suspend fun getAlertByHash(hash: Long): EmergencyEntity?

    @Query("SELECT * FROM emergency_alerts WHERE isSelfCreated = 1 ORDER BY createdAtMillis DESC LIMIT 1")
    fun getLatestSelfAlertFlow(): Flow<EmergencyEntity?>

    @Query("SELECT * FROM emergency_alerts WHERE isSelfCreated = 1 ORDER BY createdAtMillis DESC LIMIT 1")
    suspend fun getLatestSelfAlert(): EmergencyEntity?

    @Query("SELECT * FROM emergency_alerts WHERE ttl > 0 AND isSelfCreated = 0 ORDER BY createdAtMillis DESC LIMIT 50")
    suspend fun getRelayQueue(): List<EmergencyEntity>

    @Query("SELECT COUNT(*) FROM emergency_alerts WHERE packetHash = :hash")
    suspend fun countByHash(hash: Long): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlert(alert: EmergencyEntity)

    @Update
    suspend fun updateAlert(alert: EmergencyEntity)

    @Query("UPDATE emergency_alerts SET customNote = :note, rawBytes = :rawBytes, updatedAtMillis = :now WHERE packetHash = :hash")
    suspend fun updateMessageAndPayload(hash: Long, note: String, rawBytes: ByteArray, now: Long = System.currentTimeMillis())

    @Query("UPDATE emergency_alerts SET status = :status, updatedAtMillis = :now WHERE packetHash = :hash")
    suspend fun updateStatus(hash: Long, status: String, now: Long = System.currentTimeMillis())

    @Query("UPDATE emergency_alerts SET relayCount = relayCount + 1, ttl = CASE WHEN ttl > 1 THEN ttl - 1 ELSE 0 END WHERE packetHash = :hash")
    suspend fun recordRelay(hash: Long)

    @Query("DELETE FROM emergency_alerts WHERE packetHash NOT IN (SELECT packetHash FROM emergency_alerts ORDER BY createdAtMillis DESC LIMIT :maxEntries)")
    suspend fun pruneOldAlerts(maxEntries: Int = 100)

    @Query("DELETE FROM emergency_alerts WHERE packetHash = :hash")
    suspend fun deleteByHash(hash: Long)

    @Query("DELETE FROM emergency_alerts")
    suspend fun clearAll()
}
