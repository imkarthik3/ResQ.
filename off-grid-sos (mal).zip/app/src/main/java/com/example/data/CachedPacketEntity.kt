package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "cached_packets")
data class CachedPacketEntity(
    @PrimaryKey val packetHash: Long,
    val protocolVersion: Int,
    val latitude: Float,
    val longitude: Float,
    val triageFlags: Int,
    val headcount: Int,
    val batteryPercent: Int,
    val ttl: Int,
    val timestampSeconds: Long,
    val receivedAtMillis: Long = System.currentTimeMillis(),
    val isSelfCreated: Boolean = false,
    val rawBytes: ByteArray,
    val relayCount: Int = 0,
    val customNote: String = ""
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false
        other as CachedPacketEntity
        return packetHash == other.packetHash
    }

    override fun hashCode(): Int {
        return packetHash.hashCode()
    }
}
