package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [EmergencyEntity::class, CachedPacketEntity::class],
    version = 2,
    exportSchema = false
)
abstract class EmergencyDatabase : RoomDatabase() {
    abstract fun emergencyDao(): EmergencyDao
    abstract fun packetDao(): EmergencyPacketDao

    companion object {
        @Volatile
        private var INSTANCE: EmergencyDatabase? = null

        fun getInstance(context: Context): EmergencyDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    EmergencyDatabase::class.java,
                    "mesh_emergency.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}

