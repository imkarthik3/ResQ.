package com.example.serializer

import com.example.model.SosPacket
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest

object PacketSerializer {
    const val PACKET_SIZE = 30
    const val CHECKSUM_SIZE = 5
    const val PAYLOAD_AUTH_SIZE = 25
    private const val AUTH_SALT = "OFFGRID_MESH_SOS_AUTH_V1"

    /**
     * Serializes a SosPacket into an exact 30-byte binary frame for BLE advertisement.
     *
     * Byte Layout:
     * - Byte 0: Protocol Version (0x01 = SOS)
     * - Bytes 1-8: 8-byte Unique Packet Hash (UUID for mesh deduplication)
     * - Bytes 9-12: Float32 Latitude
     * - Bytes 13-16: Float32 Longitude
     * - Bytes 17-18: 16-bit Triage Bitmask (supporting all 9 pre-defined flags)
     * - Byte 19: Headcount (4 bits: 1-15) & Battery % (4 bits: 0-100% scaled)
     * - Byte 20: Hop Count / TTL (Initialized to 5)
     * - Bytes 21-24: Epoch Timestamp (seconds)
     * - Bytes 25-29: Truncated 5-byte Verification Checksum / Auth Signature
     */
    fun serialize(packet: SosPacket): ByteArray {
        val buffer = ByteBuffer.allocate(PACKET_SIZE).order(ByteOrder.BIG_ENDIAN)

        // Byte 0: Protocol Version / Type
        buffer.put(packet.protocolVersion)

        // Bytes 1-8: Unique 8-byte Packet Hash (deduplication)
        buffer.putLong(packet.packetHash)

        // Bytes 9-12: Float32 Latitude
        buffer.putFloat(packet.latitude)

        // Bytes 13-16: Float32 Longitude
        buffer.putFloat(packet.longitude)

        // Bytes 17-18: 16-bit Triage Bitmask
        buffer.putShort(packet.triageFlags)

        // Byte 19: Headcount (4 bits: 1-15) & Battery % (4 bits: 0-100% scaled to 0-15)
        val headcountNibble = packet.headcount.coerceIn(1, 15) and 0x0F
        val batteryNibble = ((packet.batteryPercent.coerceIn(0, 100) * 15) / 100) and 0x0F
        val combinedNibbles = (headcountNibble shl 4) or batteryNibble
        buffer.put(combinedNibbles.toByte())

        // Byte 20: Hop Count / TTL
        buffer.put(packet.ttl)

        // Bytes 21-24: Epoch Timestamp (seconds)
        buffer.putInt(packet.timestampSeconds.toInt())

        // Bytes 25-29: 5-byte Verification Checksum / Signature
        val payloadForAuth = ByteArray(PAYLOAD_AUTH_SIZE)
        System.arraycopy(buffer.array(), 0, payloadForAuth, 0, PAYLOAD_AUTH_SIZE)
        val checksum = computeChecksum(payloadForAuth)
        buffer.put(checksum)

        return buffer.array()
    }

    /**
     * Deserializes an exact 30-byte binary array into a SosPacket.
     * Returns null if size is invalid or checksum verification fails.
     */
    fun deserialize(data: ByteArray): SosPacket? {
        if (data.size < PACKET_SIZE) return null

        val buffer = ByteBuffer.wrap(data, 0, PACKET_SIZE).order(ByteOrder.BIG_ENDIAN)
        val protocolVersion = buffer.get()
        val packetHash = buffer.getLong()
        val latitude = buffer.getFloat()
        val longitude = buffer.getFloat()
        val triageFlags = buffer.getShort()
        val combinedNibble = buffer.get().toInt() and 0xFF
        val headcount = (combinedNibble ushr 4) and 0x0F
        val batteryNibble = combinedNibble and 0x0F
        val batteryPercent = (batteryNibble * 100) / 15
        val ttl = buffer.get()
        val timestampSeconds = buffer.getInt().toLong() and 0xFFFFFFFFL

        val checksumReceived = ByteArray(CHECKSUM_SIZE)
        buffer.get(checksumReceived)

        // Validate 5-byte Checksum
        val payloadForAuth = ByteArray(PAYLOAD_AUTH_SIZE)
        System.arraycopy(data, 0, payloadForAuth, 0, PAYLOAD_AUTH_SIZE)
        val expectedChecksum = computeChecksum(payloadForAuth)

        if (!checksumReceived.contentEquals(expectedChecksum)) {
            // Checksum failure - corrupt or forged packet
            return null
        }

        return SosPacket(
            protocolVersion = protocolVersion,
            packetHash = packetHash,
            latitude = latitude,
            longitude = longitude,
            triageFlags = triageFlags,
            headcount = if (headcount == 0) 1 else headcount,
            batteryPercent = batteryPercent,
            ttl = ttl,
            timestampSeconds = timestampSeconds,
            checksum = checksumReceived
        )
    }

    /**
     * Generates an authenticated WAKE_SIREN rescue command packet.
     */
    fun createWakeSirenPacket(targetHash: Long = 0L): ByteArray {
        val packet = SosPacket(
            protocolVersion = SosPacket.PROTOCOL_WAKE_SIREN,
            packetHash = targetHash,
            latitude = 0f,
            longitude = 0f,
            triageFlags = 0,
            headcount = 1,
            batteryPercent = 100,
            ttl = 3,
            timestampSeconds = System.currentTimeMillis() / 1000
        )
        return serialize(packet)
    }

    /**
     * Computes a 5-byte SHA-256 HMAC-style checksum for tamper-proof off-grid auth.
     */
    fun computeChecksum(payload: ByteArray): ByteArray {
        val md = MessageDigest.getInstance("SHA-256")
        md.update(AUTH_SALT.toByteArray(Charsets.UTF_8))
        md.update(payload)
        val fullHash = md.digest()
        val truncated = ByteArray(CHECKSUM_SIZE)
        System.arraycopy(fullHash, 0, truncated, 0, CHECKSUM_SIZE)
        return truncated
    }
}
