package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.sin

object SirenManager {
    private const val TAG = "SirenManager"
    private const val SAMPLE_RATE = 44100

    private val _isSirenActive = MutableStateFlow(false)
    val isSirenActive: StateFlow<Boolean> = _isSirenActive.asStateFlow()

    // 5-second countdown state for pre-vibration safety prompt ("Siren activating in 5s - Tap if conscious")
    private val _countdownSecondsRemaining = MutableStateFlow(0)
    val countdownSecondsRemaining: StateFlow<Int> = _countdownSecondsRemaining.asStateFlow()

    private val _isPreVibrating = MutableStateFlow(false)
    val isPreVibrating: StateFlow<Boolean> = _isPreVibrating.asStateFlow()

    private var countdownJob: Job? = null
    private var sirenJob: Job? = null
    private var audioTrack: AudioTrack? = null
    private var vibrator: Vibrator? = null

    /**
     * Rescuer Triggered Safe Siren Sequence:
     * Device first triggers intense tactile vibration and a 5-second countdown
     * with an on-screen cancel prompt ("Siren activating in 5s - Tap if conscious").
     * If conscious victim cancels within 5 seconds, acoustic siren is aborted.
     * If not cancelled, blast the acoustic distress siren at max volume.
     */
    fun triggerSafeSirenSequence(context: Context) {
        if (_isSirenActive.value || _isPreVibrating.value) return

        initVibrator(context)
        _isPreVibrating.value = true
        _countdownSecondsRemaining.value = 5

        // Intense pre-vibration waveform
        startTactileVibration()

        countdownJob = CoroutineScope(Dispatchers.Default).launch {
            for (sec in 5 downTo 1) {
                _countdownSecondsRemaining.value = sec
                delay(1000L)
            }
            _countdownSecondsRemaining.value = 0
            _isPreVibrating.value = false

            // Blast high-decibel acoustic siren
            startSiren(context)
        }
    }

    /**
     * Cancels the 5-second pre-siren countdown if the user taps "I'm conscious / Cancel".
     */
    fun cancelPreSiren() {
        countdownJob?.cancel()
        countdownJob = null
        _isPreVibrating.value = false
        _countdownSecondsRemaining.value = 0
        vibrator?.cancel()
    }

    /**
     * Triggers the high-decibel sub-debris acoustic rescue siren.
     * Bypasses silent/vibrate mode using STREAM_ALARM at maximum decibels.
     */
    fun startSiren(context: Context) {
        cancelPreSiren()
        if (_isSirenActive.value) return
        _isSirenActive.value = true

        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        audioManager?.let { am ->
            try {
                val maxVolume = am.getStreamMaxVolume(AudioManager.STREAM_ALARM)
                am.setStreamVolume(AudioManager.STREAM_ALARM, maxVolume, 0)
            } catch (e: Exception) {
                Log.w(TAG, "Unable to force max volume: ${e.message}")
            }
        }

        initVibrator(context)

        sirenJob = CoroutineScope(Dispatchers.Default).launch {
            try {
                var minBufferSize = AudioTrack.getMinBufferSize(
                    SAMPLE_RATE,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                )
                if (minBufferSize <= 0) {
                    minBufferSize = SAMPLE_RATE * 2
                } else {
                    minBufferSize *= 2
                }

                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .setFlags(AudioAttributes.FLAG_AUDIBILITY_ENFORCED)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(SAMPLE_RATE)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(minBufferSize)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()

                audioTrack = track
                track.play()

                // Continuous tactile vibration
                startTactileVibration()

                var phase = 0.0
                val lowFreq = 880.0  // A5
                val highFreq = 1760.0 // A6

                while (isActive && _isSirenActive.value) {
                    // Alternates between 880Hz and 1760Hz
                    val stepSamples = SAMPLE_RATE / 4
                    val samples = ShortArray(stepSamples)

                    for (cycle in 0 until 4) {
                        val currentFreq = if (cycle % 2 == 0) highFreq else lowFreq
                        val phaseIncrement = 2.0 * Math.PI * currentFreq / SAMPLE_RATE

                        for (i in 0 until stepSamples) {
                            val sample = (sin(phase) * 32767.0).toInt().toShort()
                            samples[i] = sample
                            phase += phaseIncrement
                            if (phase > 2.0 * Math.PI) phase -= 2.0 * Math.PI
                        }

                        if (track.playState == AudioTrack.PLAYSTATE_PLAYING) {
                            track.write(samples, 0, samples.size)
                        }
                    }

                    // Short pause (200ms) between bursts
                    val silenceSamples = ShortArray(SAMPLE_RATE / 5)
                    if (track.playState == AudioTrack.PLAYSTATE_PLAYING) {
                        track.write(silenceSamples, 0, silenceSamples.size)
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error in siren synthesizer", e)
            } finally {
                cleanup()
            }
        }
    }

    /**
     * Stops the rescue siren immediately.
     */
    fun stopSiren() {
        _isSirenActive.value = false
        _isPreVibrating.value = false
        _countdownSecondsRemaining.value = 0
        countdownJob?.cancel()
        countdownJob = null
        sirenJob?.cancel()
        sirenJob = null
        cleanup()
    }

    private fun initVibrator(context: Context) {
        if (vibrator == null) {
            vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }
        }
    }

    private fun startTactileVibration() {
        try {
            val pattern = longArrayOf(0, 400, 150, 400, 150, 600)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val effect = VibrationEffect.createWaveform(pattern, 0)
                vibrator?.vibrate(effect)
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(pattern, 0)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed vibration: ${e.message}")
        }
    }

    private fun cleanup() {
        try {
            vibrator?.cancel()
            audioTrack?.let {
                if (it.playState == AudioTrack.PLAYSTATE_PLAYING) {
                    it.stop()
                }
                it.release()
            }
            audioTrack = null
        } catch (e: Exception) {
            Log.w(TAG, "AudioTrack cleanup error: ${e.message}")
        }
    }
}
