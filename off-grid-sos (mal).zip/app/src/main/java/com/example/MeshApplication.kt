package com.example

import android.app.Application
import com.example.data.EmergencyDatabase
import com.example.location.GpsManager
import com.example.repository.MeshRepository

class MeshApplication : Application() {

    lateinit var database: EmergencyDatabase
        private set

    lateinit var repository: MeshRepository
        private set

    lateinit var gpsManager: GpsManager
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        database = EmergencyDatabase.getInstance(this)
        repository = MeshRepository(database)
        gpsManager = GpsManager(this)
    }

    companion object {
        lateinit var instance: MeshApplication
            private set
    }
}
