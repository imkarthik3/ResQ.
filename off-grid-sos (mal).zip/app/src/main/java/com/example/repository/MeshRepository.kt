package com.example.repository

import com.example.data.CachedPacketEntity
import com.example.data.EmergencyDao
import com.example.data.EmergencyDatabase
import com.example.data.EmergencyEntity
import com.example.model.SosPacket
import com.example.serializer.PacketSerializer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class MeshRepository(private val database: EmergencyDatabase) {
    private val emergencyDao: EmergencyDao = database.emergencyDao()
    private val packetDao = database.packetDao()

    val allCachedPackets: Flow<List<CachedPacketEntity>> = packetDao.getAllPacketsFlow()
    val allEmergencyAlerts: Flow<List<EmergencyEntity>> = emergencyDao.getAllAlertsFlow()
    val latestSelfAlert: Flow<EmergencyEntity?> = emergencyDao.getLatestSelfAlertFlow()

    suspend fun getLatestSelfAlert(): EmergencyEntity? = withContext(Dispatchers.IO) {
        emergencyDao.getLatestSelfAlert()
    }

    suspend fun saveSelfPacket(
        packet: SosPacket,
        note: String = "",
        status: String = EmergencyEntity.STATUS_PENDING_DELIVERY
    ): EmergencyEntity {
        val raw = PacketSerializer.serialize(packet)
        val alertEntity = EmergencyEntity(
            packetHash = packet.packetHash,
            protocolVersion = packet.protocolVersion.toInt(),
            latitude = packet.latitude,
            longitude = packet.longitude,
            triageBitmask = packet.triageFlags.toInt() and 0xFFFF,
            headcount = packet.headcount,
            batteryPercent = packet.batteryPercent,
            ttl = packet.ttl.toInt(),
            timestampSeconds = packet.timestampSeconds,
            status = status,
            customNote = note,
            rawBytes = raw,
            isSelfCreated = true,
            relayCount = 0,
            createdAtMillis = System.currentTimeMillis(),
            updatedAtMillis = System.currentTimeMillis()
        )

        val cachedEntity = CachedPacketEntity(
            packetHash = packet.packetHash,
            protocolVersion = packet.protocolVersion.toInt(),
            latitude = packet.latitude,
            longitude = packet.longitude,
            triageFlags = packet.triageFlags.toInt() and 0xFFFF,
            headcount = packet.headcount,
            batteryPercent = packet.batteryPercent,
            ttl = packet.ttl.toInt(),
            timestampSeconds = packet.timestampSeconds,
            receivedAtMillis = System.currentTimeMillis(),
            isSelfCreated = true,
            rawBytes = raw,
            relayCount = 0,
            customNote = note
        )

        withContext(Dispatchers.IO) {
            emergencyDao.insertAlert(alertEntity)
            packetDao.insertPacket(cachedEntity)
            emergencyDao.pruneOldAlerts(100)
            packetDao.pruneOldRingBuffer(100)
        }
        return alertEntity
    }

    suspend fun updateSelfNoteAndPayload(hash: Long, note: String, packet: SosPacket) {
        val raw = PacketSerializer.serialize(packet)
        withContext(Dispatchers.IO) {
            emergencyDao.updateMessageAndPayload(hash, note, raw)
            // also update cached packet
            val cached = CachedPacketEntity(
                packetHash = hash,
                protocolVersion = packet.protocolVersion.toInt(),
                latitude = packet.latitude,
                longitude = packet.longitude,
                triageFlags = packet.triageFlags.toInt() and 0xFFFF,
                headcount = packet.headcount,
                batteryPercent = packet.batteryPercent,
                ttl = packet.ttl.toInt(),
                timestampSeconds = packet.timestampSeconds,
                receivedAtMillis = System.currentTimeMillis(),
                isSelfCreated = true,
                rawBytes = raw,
                customNote = note
            )
            packetDao.insertPacket(cached)
        }
    }

    suspend fun updateAlertStatus(hash: Long, status: String) {
        withContext(Dispatchers.IO) {
            emergencyDao.updateStatus(hash, status)
        }
    }

    suspend fun handleReceivedPacket(data: ByteArray): Pair<SosPacket?, Boolean> {
        val packet = PacketSerializer.deserialize(data) ?: return Pair(null, false)
        return withContext(Dispatchers.IO) {
            val exists = packetDao.countByHash(packet.packetHash) > 0
            if (!exists) {
                val cachedEntity = CachedPacketEntity(
                    packetHash = packet.packetHash,
                    protocolVersion = packet.protocolVersion.toInt(),
                    latitude = packet.latitude,
                    longitude = packet.longitude,
                    triageFlags = packet.triageFlags.toInt() and 0xFFFF,
                    headcount = packet.headcount,
                    batteryPercent = packet.batteryPercent,
                    ttl = packet.ttl.toInt(),
                    timestampSeconds = packet.timestampSeconds,
                    receivedAtMillis = System.currentTimeMillis(),
                    isSelfCreated = false,
                    rawBytes = data,
                    relayCount = 0
                )
                val alertEntity = EmergencyEntity(
                    packetHash = packet.packetHash,
                    protocolVersion = packet.protocolVersion.toInt(),
                    latitude = packet.latitude,
                    longitude = packet.longitude,
                    triageBitmask = packet.triageFlags.toInt() and 0xFFFF,
                    headcount = packet.headcount,
                    batteryPercent = packet.batteryPercent,
                    ttl = packet.ttl.toInt(),
                    timestampSeconds = packet.timestampSeconds,
                    status = EmergencyEntity.STATUS_DELIVERED,
                    customNote = "",
                    rawBytes = data,
                    isSelfCreated = false,
                    relayCount = 0,
                    createdAtMillis = System.currentTimeMillis()
                )
                packetDao.insertPacket(cachedEntity)
                emergencyDao.insertAlert(alertEntity)
                packetDao.pruneOldRingBuffer(100)
                emergencyDao.pruneOldAlerts(100)
                Pair(packet, true) // New packet stored
            } else {
                Pair(packet, false) // Duplicate
            }
        }
    }

    suspend fun getRelayPackets(): List<CachedPacketEntity> = withContext(Dispatchers.IO) {
        packetDao.getRelayQueue()
    }

    suspend fun markRelayed(hash: Long) = withContext(Dispatchers.IO) {
        packetDao.recordRelay(hash)
        emergencyDao.recordRelay(hash)
    }

    suspend fun pruneOldPackets(maxEntries: Int = 100) = withContext(Dispatchers.IO) {
        packetDao.pruneOldRingBuffer(maxEntries)
        emergencyDao.pruneOldAlerts(maxEntries)
    }

    suspend fun deletePacket(hash: Long) = withContext(Dispatchers.IO) {
        packetDao.deleteByHash(hash)
        emergencyDao.deleteByHash(hash)
    }

    suspend fun clearBuffer() = withContext(Dispatchers.IO) {
        packetDao.clearAll()
        emergencyDao.clearAll()
    }
}
