package com.example.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.MeshApplication
import com.example.audio.SirenManager
import com.example.data.CachedPacketEntity
import com.example.data.EmergencyEntity
import com.example.location.GpsState
import com.example.model.AppLanguage
import com.example.model.SosPacket
import com.example.model.TriageBitmaskHelper
import com.example.model.TriageFlag
import com.example.serializer.PacketSerializer
import com.example.service.BleMeshService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

class MeshViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as MeshApplication
    private val repository = app.repository
    private val gpsManager = app.gpsManager

    // Persistent Device SOS Packet Hash
    val myPacketHash: Long by lazy {
        val prefs = app.getSharedPreferences("mesh_sos_prefs", Context.MODE_PRIVATE)
        var hash = prefs.getLong("device_packet_hash", 0L)
        if (hash == 0L) {
            hash = UUID.randomUUID().mostSignificantBits
            prefs.edit().putLong("device_packet_hash", hash).apply()
        }
        hash
    }

    // Bilingual Language Toggle State (English / Malayalam)
    private val _currentLanguage = MutableStateFlow(AppLanguage.ENGLISH)
    val currentLanguage: StateFlow<AppLanguage> = _currentLanguage.asStateFlow()

    // Live GPS state from standalone satellite tracker
    val gpsState: StateFlow<GpsState> = gpsManager.gpsState

    // Live Service State
    val isBroadcasting: StateFlow<Boolean> = BleMeshService.isBroadcasting
    val isPowerSaverMode: StateFlow<Boolean> = BleMeshService.isPowerSaverMode
    val sleepIntervalMinutes: StateFlow<Int> = BleMeshService.sleepIntervalMinutes
    val dutyCyclePhase: StateFlow<String> = BleMeshService.dutyCyclePhase
    val nearbyNodesCount: StateFlow<Int> = BleMeshService.nearbyNodesCount
    val relayedPacketsCount: StateFlow<Int> = BleMeshService.relayedPacketsCount
    val batteryLevel: StateFlow<Int> = BleMeshService.batteryLevel
    val autoPowerSaverAlert: StateFlow<Boolean> = BleMeshService.autoPowerSaverAlert
    val currentDutyTier: StateFlow<String> = BleMeshService.currentDutyTier

    // Siren & Pre-Vibration Countdown State
    val isSirenActive: StateFlow<Boolean> = SirenManager.isSirenActive
    val isPreVibrating: StateFlow<Boolean> = SirenManager.isPreVibrating
    val countdownSecondsRemaining: StateFlow<Int> = SirenManager.countdownSecondsRemaining

    // Cached Room DB Packets
    val cachedPackets: StateFlow<List<CachedPacketEntity>> = repository.allCachedPackets
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Latest self emergency alert in Room DB
    val latestSelfAlert: StateFlow<EmergencyEntity?> = repository.latestSelfAlert
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Victim Input States
    private val _selectedTriageFlags = MutableStateFlow<Set<TriageFlag>>(emptySet())
    val selectedTriageFlags: StateFlow<Set<TriageFlag>> = _selectedTriageFlags.asStateFlow()

    private val _headcount = MutableStateFlow(1)
    val headcount: StateFlow<Int> = _headcount.asStateFlow()

    private val _customNote = MutableStateFlow("")
    val customNote: StateFlow<String> = _customNote.asStateFlow()

    private val _isMessageCardExpanded = MutableStateFlow(false)
    val isMessageCardExpanded: StateFlow<Boolean> = _isMessageCardExpanded.asStateFlow()

    private val _showSettingsSheet = MutableStateFlow(false)
    val showSettingsSheet: StateFlow<Boolean> = _showSettingsSheet.asStateFlow()

    private val _hasPermissions = MutableStateFlow(false)
    val hasPermissions: StateFlow<Boolean> = _hasPermissions.asStateFlow()

    // Calculated Battery Life Estimate
    val batteryLifeEstimate: StateFlow<String> = combine(
        batteryLevel,
        isPowerSaverMode
    ) { battery, powerSaver ->
        calculateBatteryLifeEstimate(battery, powerSaver)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "~3.8 Days")

    init {
        gpsManager.startGpsUpdates()
    }

    fun toggleLanguage() {
        _currentLanguage.value = if (_currentLanguage.value == AppLanguage.ENGLISH) {
            AppLanguage.MALAYALAM
        } else {
            AppLanguage.ENGLISH
        }
    }

    fun setLanguage(language: AppLanguage) {
        _currentLanguage.value = language
    }

    fun setPermissionsGranted(granted: Boolean) {
        _hasPermissions.value = granted
        if (granted) {
            gpsManager.startGpsUpdates()
        }
    }

    /**
     * 1-Tap SOS Trigger:
     * Queries offline GPS coordinates, packs selected 16-bit bitmask into 30-byte frame,
     * starts background BLE advertising, saves alert to Room DB, and auto-resets UI to clean stage.
     */
    fun trigger1TapSos() {
        val currentGps = gpsState.value
        val bitmask = TriageBitmaskHelper.toBitmask(_selectedTriageFlags.value)
        val packet = SosPacket(
            protocolVersion = SosPacket.PROTOCOL_SOS,
            packetHash = myPacketHash,
            latitude = currentGps.latitude.toFloat(),
            longitude = currentGps.longitude.toFloat(),
            triageFlags = bitmask,
            headcount = _headcount.value,
            batteryPercent = batteryLevel.value,
            ttl = SosPacket.DEFAULT_TTL,
            timestampSeconds = System.currentTimeMillis() / 1000
        )

        val serialized = PacketSerializer.serialize(packet)

        viewModelScope.launch {
            // Save in Room DB as PENDING_DELIVERY
            repository.saveSelfPacket(
                packet = packet,
                note = _customNote.value,
                status = EmergencyEntity.STATUS_PENDING_DELIVERY
            )

            // Start foreground BLE mesh broadcast service with payload
            val intent = Intent(app, BleMeshService::class.java).apply {
                action = BleMeshService.ACTION_START_BROADCAST
                putExtra(BleMeshService.EXTRA_PAYLOAD_BYTES, serialized)
            }
            startMeshServiceIntent(intent)

            // Auto-reset UI to clean stage
            _selectedTriageFlags.value = emptySet()
            _headcount.value = 1
        }
    }

    /**
     * Toggles SOS broadcast state. If broadcasting, stops it; if stopped, triggers 1-Tap SOS.
     */
    fun toggleSosBroadcast() {
        if (isBroadcasting.value) {
            stopSosBroadcast()
        } else {
            trigger1TapSos()
        }
    }

    fun stopSosBroadcast() {
        val intent = Intent(app, BleMeshService::class.java).apply {
            action = BleMeshService.ACTION_STOP_BROADCAST
        }
        startMeshServiceIntent(intent)

        viewModelScope.launch {
            repository.updateAlertStatus(myPacketHash, EmergencyEntity.STATUS_RESOLVED)
        }
    }

    /**
     * Message Attachment & Update:
     * Updates the existing record in Room DB and refreshes the BLE advertising payload dynamically.
     */
    fun attachAndUpdateSos(messageText: String) {
        val trimmed = messageText.trim()
        _customNote.value = trimmed

        val currentGps = gpsState.value
        val bitmask = TriageBitmaskHelper.toBitmask(_selectedTriageFlags.value)
        val packet = SosPacket(
            protocolVersion = SosPacket.PROTOCOL_SOS,
            packetHash = myPacketHash,
            latitude = currentGps.latitude.toFloat(),
            longitude = currentGps.longitude.toFloat(),
            triageFlags = bitmask,
            headcount = _headcount.value,
            batteryPercent = batteryLevel.value,
            ttl = SosPacket.DEFAULT_TTL,
            timestampSeconds = System.currentTimeMillis() / 1000,
            customNote = trimmed
        )

        val serialized = PacketSerializer.serialize(packet)

        viewModelScope.launch {
            repository.updateSelfNoteAndPayload(myPacketHash, trimmed, packet)

            val intent = Intent(app, BleMeshService::class.java).apply {
                action = BleMeshService.ACTION_UPDATE_PAYLOAD
                putExtra(BleMeshService.EXTRA_PAYLOAD_BYTES, serialized)
            }
            startMeshServiceIntent(intent)
        }
    }

    // Triage chip multi-selection
    fun toggleTriageFlag(flag: TriageFlag) {
        val current = _selectedTriageFlags.value.toMutableSet()
        if (current.contains(flag)) {
            current.remove(flag)
        } else {
            current.add(flag)
        }
        _selectedTriageFlags.value = current
    }

    fun isTriageSelected(flag: TriageFlag): Boolean {
        return _selectedTriageFlags.value.contains(flag)
    }

    fun clearTriageFlags() {
        _selectedTriageFlags.value = emptySet()
    }

    // Headcount Stepper
    fun incrementHeadcount() {
        if (_headcount.value < 15) {
            _headcount.value += 1
        }
    }

    fun decrementHeadcount() {
        if (_headcount.value > 1) {
            _headcount.value -= 1
        }
    }

    fun updateCustomNote(note: String) {
        _customNote.value = note
    }

    fun toggleMessageCardExpansion() {
        _isMessageCardExpanded.value = !_isMessageCardExpanded.value
    }

    fun setMessageCardExpanded(expanded: Boolean) {
        _isMessageCardExpanded.value = expanded
    }

    fun setShowSettingsSheet(show: Boolean) {
        _showSettingsSheet.value = show
    }

    fun togglePowerSaver() {
        val intent = Intent(app, BleMeshService::class.java).apply {
            action = BleMeshService.ACTION_TOGGLE_POWER_SAVER
        }
        startMeshServiceIntent(intent)
    }

    fun setSleepInterval(minutes: Int) {
        val intent = Intent(app, BleMeshService::class.java).apply {
            action = BleMeshService.ACTION_SET_SLEEP_INTERVAL
            putExtra(BleMeshService.EXTRA_INTERVAL_MINUTES, minutes)
        }
        startMeshServiceIntent(intent)
    }

    fun dismissBatteryAlert() {
        BleMeshService.dismissBatteryAlert()
    }

    // Siren Controls
    fun startSiren() {
        SirenManager.startSiren(app)
    }

    fun stopSiren() {
        SirenManager.stopSiren()
    }

    fun cancelPreSiren() {
        SirenManager.cancelPreSiren()
    }

    // Rescuer Wake-Up Ping
    fun triggerRescuerAcousticWake() {
        val intent = Intent(app, BleMeshService::class.java).apply {
            action = BleMeshService.ACTION_TRIGGER_RESCUER_SIREN
        }
        startMeshServiceIntent(intent)
    }

    private fun startMeshServiceIntent(intent: Intent) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                app.startForegroundService(intent)
            } else {
                app.startService(intent)
            }
        } catch (e: Exception) {
            android.util.Log.e("MeshViewModel", "Failed to start service intent", e)
        }
    }

    private fun calculateBatteryLifeEstimate(battery: Int, powerSaver: Boolean): String {
        return if (powerSaver) {
            val days = (battery.toDouble() / 100.0) * 4.8
            String.format(java.util.Locale.US, "~%.1f Days", days)
        } else {
            val hours = (battery.toDouble() / 100.0) * 42.0
            if (hours >= 24) {
                String.format(java.util.Locale.US, "~%.1f Days", hours / 24.0)
            } else {
                String.format(java.util.Locale.US, "~%d Hours", hours.toInt())
            }
        }
    }
}
