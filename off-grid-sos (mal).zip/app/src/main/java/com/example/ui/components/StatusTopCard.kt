package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.BluetoothSearching
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.GpsNotFixed
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.location.GpsState
import com.example.model.AppLanguage
import com.example.ui.theme.CautionAmber
import com.example.ui.theme.EmergencyRed
import com.example.ui.theme.MeshGreen
import com.example.ui.theme.TactileSurface
import com.example.ui.theme.TactileSurfaceVariant
import java.util.Locale

@Composable
fun StatusTopCard(
    gpsState: GpsState,
    isBroadcasting: Boolean,
    batteryPercent: Int,
    batteryLifeEstimate: String,
    powerSaverMode: Boolean,
    dutyCyclePhase: String,
    nearbyNodesCount: Int,
    language: AppLanguage = AppLanguage.ENGLISH,
    onCardClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(TactileSurface)
            .border(1.dp, Color(0xFF263242), RoundedCornerShape(16.dp))
            .clickable(onClick = onCardClick)
            .padding(16.dp)
            .testTag("status_top_card")
    ) {
        Column {
            // Row 1: GPS Satellite Status & Battery Estimate
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // GPS status badge
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(
                                when {
                                    gpsState.isChipsetSleeping -> MeshGreen
                                    gpsState.isFixed -> MeshGreen
                                    else -> CautionAmber
                                }
                            )
                    )
                    Spacer(modifier = Modifier.width(8.dp))

                    val gpsLabel = if (language == AppLanguage.MALAYALAM) {
                        when {
                            gpsState.isChipsetSleeping -> "GPS ലോക്കായി (പവർ സേവർ സജീവം)"
                            gpsState.isFixed -> "GPS കൃത്യം (ഉപഗ്രഹങ്ങൾ: ${gpsState.satellitesUsedInFix.coerceAtLeast(4)})"
                            else -> "ഉപഗ്രഹങ്ങൾ കണ്ടെത്തുന്നു (${gpsState.satellitesInView})"
                        }
                    } else {
                        when {
                            gpsState.isChipsetSleeping -> "GPS Locked (Chipset Sleeping)"
                            gpsState.isFixed -> "GPS Fixed (Sats: ${gpsState.satellitesUsedInFix.coerceAtLeast(4)})"
                            else -> "Acquiring GPS (Sats: ${gpsState.satellitesInView})"
                        }
                    }

                    Text(
                        text = gpsLabel,
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                    )
                }

                // Battery Estimate Badge
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.BatteryChargingFull,
                        contentDescription = "Battery Status",
                        tint = if (batteryPercent < 30) EmergencyRed else if (batteryPercent < 60) CautionAmber else MeshGreen,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "$batteryPercent% ($batteryLifeEstimate)",
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Row 2: Live Coordinates Readout (Stand-alone satellite GPS)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(TactileSurfaceVariant)
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = String.format(
                        Locale.US,
                        "COORDS: %.4f° %s, %.4f° %s",
                        Math.abs(gpsState.latitude),
                        if (gpsState.latitude >= 0) "N" else "S",
                        Math.abs(gpsState.longitude),
                        if (gpsState.longitude >= 0) "E" else "W"
                    ),
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = Color(0xFF9EABB8),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                )

                Text(
                    text = if (gpsState.accuracyMeters > 0) "±${gpsState.accuracyMeters.toInt()}m" else "OFFLINE",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = if (gpsState.isFixed) MeshGreen else CautionAmber,
                        fontWeight = FontWeight.Bold
                    )
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Row 3: Mesh BLE Radio state & Nearby Nodes
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.BluetoothSearching,
                        contentDescription = "BLE Radio Mesh",
                        tint = if (isBroadcasting) MeshGreen else Color(0xFF6E7E91),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))

                    val radioLabel = if (language == AppLanguage.MALAYALAM) {
                        if (isBroadcasting) "BLE മെഷ്: സജീവം" else "റേഡിയോ: നിഷ്‌ക്രിയം"
                    } else {
                        if (isBroadcasting) "BLE Mesh: $dutyCyclePhase" else "BLE Radio: Idle"
                    }

                    Text(
                        text = radioLabel,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = if (isBroadcasting) Color.White else Color(0xFF8B949E),
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp
                        )
                    )
                }

                val peersLabel = if (language == AppLanguage.MALAYALAM) {
                    if (nearbyNodesCount > 0) "കണ്ടെത്തിയവ: $nearbyNodesCount" else "തിരയുന്നു (80m)"
                } else {
                    if (nearbyNodesCount > 0) "Peers: $nearbyNodesCount node(s)" else "Peers: Searching (80m)"
                }

                Text(
                    text = peersLabel,
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = if (nearbyNodesCount > 0) MeshGreen else Color(0xFF8B949E),
                        fontWeight = FontWeight.Bold
                    )
                )
            }
        }
    }
}
