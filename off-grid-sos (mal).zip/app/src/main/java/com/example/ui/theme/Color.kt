package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Tactical Disaster Palette - High Contrast & OLED battery saving
val TacticalBlack = Color(0xFF0A0D12)
val TacticalSurface = Color(0xFF141A22)
val TacticalSurfaceVariant = Color(0xFF1E2633)
val TacticalBorder = Color(0xFF2B3746)

val TactileSurface = TacticalSurface
val TactileSurfaceVariant = TacticalSurfaceVariant
val TactileBorder = TacticalBorder

val EmergencyRed = Color(0xFFFF334B)
val EmergencyRedDark = Color(0xFF4A0E17)
val EmergencyRedPulsing = Color(0xFFFF667A)

val MeshGreen = Color(0xFF00E676)
val MeshGreenDark = Color(0xFF0A331E)

val CautionAmber = Color(0xFFFFB800)
val CautionAmberDark = Color(0xFF3B2A05)

val TextPrimary = Color(0xFFF0F6FC)
val TextSecondary = Color(0xFF8B949E)
val TextMuted = Color(0xFF5A6573)
