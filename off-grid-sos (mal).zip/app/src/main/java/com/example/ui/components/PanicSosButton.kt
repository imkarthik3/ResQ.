package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Emergency
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.ui.theme.EmergencyRed
import com.example.ui.theme.EmergencyRedDark

@Composable
fun PanicSosButton(
    isBroadcasting: Boolean,
    language: AppLanguage = AppLanguage.ENGLISH,
    onSosClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse_rings")

    val pulseScale1 by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isBroadcasting) 1.55f else 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse_scale_1"
    )

    val pulseAlpha1 by infiniteTransition.animateFloat(
        initialValue = if (isBroadcasting) 0.65f else 0.25f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse_alpha_1"
    )

    val pulseScale2 by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isBroadcasting) 1.85f else 1.28f,
        animationSpec = infiniteRepeatable(
            animation = tween(1600, delayMillis = 300, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse_scale_2"
    )

    val pulseAlpha2 by infiniteTransition.animateFloat(
        initialValue = if (isBroadcasting) 0.45f else 0.15f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1600, delayMillis = 300, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse_alpha_2"
    )

    Box(
        modifier = modifier
            .size(230.dp),
        contentAlignment = Alignment.Center
    ) {
        // Pulsing Rings (Only when broadcasting or subtle standby guidance)
        Canvas(modifier = Modifier.fillMaxSize()) {
            val centerRadius = 85.dp.toPx()
            if (isBroadcasting) {
                drawCircle(
                    color = EmergencyRed.copy(alpha = pulseAlpha2),
                    radius = centerRadius * pulseScale2
                )
            }
            drawCircle(
                color = EmergencyRed.copy(alpha = pulseAlpha1),
                radius = centerRadius * pulseScale1
            )
        }

        // The Massive Primary Emergency Button (170dp diameter)
        Box(
            modifier = Modifier
                .size(170.dp)
                .shadow(
                    elevation = if (isBroadcasting) 24.dp else 12.dp,
                    shape = CircleShape,
                    ambientColor = EmergencyRed,
                    spotColor = EmergencyRed
                )
                .clip(CircleShape)
                .background(
                    brush = Brush.radialGradient(
                        colors = if (isBroadcasting) {
                            listOf(
                                Color(0xFFFF4D64),
                                EmergencyRed,
                                EmergencyRedDark
                            )
                        } else {
                            listOf(
                                EmergencyRed,
                                Color(0xFFC91E34),
                                EmergencyRedDark
                            )
                        }
                    )
                )
                .border(
                    width = 4.dp,
                    color = if (isBroadcasting) Color.White else Color(0xFFFF8595),
                    shape = CircleShape
                )
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = ripple(bounded = true, color = Color.White),
                    onClick = onSosClick
                )
                .testTag("panic_sos_button"),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = if (isBroadcasting) Icons.Default.Sensors else Icons.Default.Emergency,
                    contentDescription = "Emergency SOS Beacon",
                    tint = Color.White,
                    modifier = Modifier.size(44.dp)
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "SOS",
                    style = MaterialTheme.typography.displayLarge.copy(
                        fontSize = 36.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White,
                        letterSpacing = 2.sp
                    ),
                    textAlign = TextAlign.Center
                )

                val subLabel = if (isBroadcasting) {
                    if (language == AppLanguage.MALAYALAM) "പ്രക്ഷേപണം ചെയ്യുന്നു" else "TRANSMITTING"
                } else {
                    if (language == AppLanguage.MALAYALAM) "1-ടാപ്പ് രക്ഷാ സന്ദേശം" else "1-TAP RESCUE"
                }

                Text(
                    text = subLabel,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black,
                        color = if (isBroadcasting) Color(0xFF00E676) else Color(0xFFFFD5DA),
                        letterSpacing = 1.sp
                    ),
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}
