package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryAlert
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EnergySavingsLeaf
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CautionAmber
import com.example.ui.theme.CautionAmberDark
import com.example.ui.theme.EmergencyRed
import com.example.ui.theme.MeshGreen
import com.example.ui.theme.TactileBorder
import com.example.ui.theme.TactileSurface
import com.example.ui.theme.TactileSurfaceVariant

@Composable
fun BatterySaverToggleCard(
    isPowerSaver: Boolean,
    sleepIntervalMinutes: Int,
    dutyCyclePhase: String,
    onToggle: () -> Unit,
    onConfigureClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(TactileSurface)
            .border(1.dp, TactileBorder, RoundedCornerShape(16.dp))
            .padding(14.dp)
            .testTag("power_saver_card")
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(if (isPowerSaver) MeshGreen.copy(alpha = 0.2f) else Color(0xFF263242)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.EnergySavingsLeaf,
                            contentDescription = "Power Saver Mesh Mode",
                            tint = if (isPowerSaver) MeshGreen else Color(0xFF8B949E),
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Text(
                            text = "Power Saver Mesh Mode",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        )
                        Text(
                            text = if (isPowerSaver) "Duty: 30s active / ${sleepIntervalMinutes}m sleep" else "Continuous Active Broadcast",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = if (isPowerSaver) MeshGreen else Color(0xFF8B949E)
                            )
                        )
                    }
                }

                Switch(
                    checked = isPowerSaver,
                    onCheckedChange = { onToggle() },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = MeshGreen,
                        uncheckedThumbColor = Color(0xFF8B949E),
                        uncheckedTrackColor = Color(0xFF263242)
                    ),
                    modifier = Modifier.testTag("power_saver_switch")
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Saves 92% battery while keeping your SOS active in background. Operates seamlessly with screen locked.",
                style = MaterialTheme.typography.bodySmall.copy(
                    color = Color(0xFFBAC5D2),
                    lineHeight = 18.sp
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Quick Configure Interval Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(TactileSurfaceVariant)
                    .clickable(onClick = onConfigureClick)
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = "Sleep Interval Settings",
                        tint = Color(0xFF8B949E),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Sleep Interval: ${sleepIntervalMinutes} min",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    )
                }

                Text(
                    text = "CUSTOMIZE",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Black,
                        color = Color(0xFF29B6F6)
                    )
                )
            }
        }
    }
}

@Composable
fun AutoPowerSaverAlertBanner(
    batteryLevel: Int,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CautionAmberDark),
        shape = RoundedCornerShape(12.dp),
        modifier = modifier
            .fillMaxWidth()
            .border(1.5.dp, CautionAmber, RoundedCornerShape(12.dp))
            .testTag("battery_alert_banner")
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.BatteryAlert,
                contentDescription = "Battery Low",
                tint = CautionAmber,
                modifier = Modifier.size(28.dp)
            )

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Battery dropped to $batteryLevel%",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = CautionAmber
                    )
                )
                Text(
                    text = "Switched to Deep-Sleep Duty Cycling to preserve mesh beacon life.",
                    style = MaterialTheme.typography.bodySmall.copy(color = Color.White)
                )
            }

            IconButton(onClick = onDismiss, modifier = Modifier.size(36.dp)) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Dismiss",
                    tint = Color.White
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SleepIntervalBottomSheet(
    currentMinutes: Int,
    onSelectMinutes: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState()

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = TactileSurface,
        dragHandle = null
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Deep-Sleep Radio Duty Cycle",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                )
                IconButton(onClick = onDismiss) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = Color.White
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "In disaster zones without chargers, duty cycling keeps your phone alive for days while periodically hopping distress packets.",
                style = MaterialTheme.typography.bodyMedium.copy(color = Color(0xFFBAC5D2))
            )

            Spacer(modifier = Modifier.height(18.dp))

            // 3 Interval choices: 5m, 15m, 30m
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                IntervalChoiceItem(
                    label = "5 min",
                    subLabel = "Frequent (~2 Days)",
                    isSelected = currentMinutes == 5,
                    onClick = { onSelectMinutes(5) },
                    modifier = Modifier.weight(1f)
                )

                IntervalChoiceItem(
                    label = "15 min (Default)",
                    subLabel = "Balanced (~4 Days)",
                    isSelected = currentMinutes == 15,
                    onClick = { onSelectMinutes(15) },
                    modifier = Modifier.weight(1f)
                )

                IntervalChoiceItem(
                    label = "30 min",
                    subLabel = "Max Life (~7 Days)",
                    isSelected = currentMinutes == 30,
                    onClick = { onSelectMinutes(30) },
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun IntervalChoiceItem(
    label: String,
    subLabel: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (isSelected) MeshGreen.copy(alpha = 0.15f) else TactileSurfaceVariant)
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = if (isSelected) MeshGreen else TactileBorder,
                shape = RoundedCornerShape(12.dp)
            )
            .clickable(onClick = onClick)
            .padding(vertical = 14.dp, horizontal = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = label,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = if (isSelected) MeshGreen else Color.White
                )
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = subLabel,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = if (isSelected) Color.White else Color(0xFF8B949E),
                    fontSize = 10.sp
                )
            )
        }
    }
}
