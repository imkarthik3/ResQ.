package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.ui.theme.CautionAmber
import com.example.ui.theme.EmergencyRed
import com.example.ui.theme.MeshGreen
import com.example.ui.theme.TactileBorder
import com.example.ui.theme.TactileSurface
import com.example.ui.theme.TactileSurfaceVariant

@Composable
fun SirenControlBar(
    isSirenActive: Boolean,
    isPreVibrating: Boolean = false,
    countdownSeconds: Int = 0,
    language: AppLanguage = AppLanguage.ENGLISH,
    onStartSiren: () -> Unit,
    onStopSiren: () -> Unit,
    onCancelPreSiren: () -> Unit = {},
    onRescuerWakeTest: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "siren_blink")
    val alphaAnim by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(400),
            repeatMode = RepeatMode.Reverse
        ),
        label = "siren_alpha"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(
                when {
                    isSirenActive -> Color(0xFF5E0B16).copy(alpha = alphaAnim)
                    isPreVibrating -> Color(0xFF4A3408).copy(alpha = alphaAnim)
                    else -> TactileSurface
                }
            )
            .border(
                width = if (isSirenActive || isPreVibrating) 2.5.dp else 1.dp,
                color = when {
                    isSirenActive -> EmergencyRed
                    isPreVibrating -> CautionAmber
                    else -> TactileBorder
                },
                shape = RoundedCornerShape(16.dp)
            )
            .padding(14.dp)
            .testTag("siren_control_bar")
    ) {
        when {
            // Safety Countdown & Pre-Vibration Stage
            isPreVibrating -> {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.NotificationsActive,
                            contentDescription = "Pre-Vibration Alert",
                            tint = CautionAmber,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (language == AppLanguage.MALAYALAM) {
                                "സൈറൺ മുഴങ്ങുന്നു: ${countdownSeconds}s"
                            } else {
                                "SIREN ACTIVATING IN ${countdownSeconds}s"
                            },
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Black,
                                color = Color.White,
                                letterSpacing = 1.sp
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = onCancelPreSiren,
                        colors = ButtonDefaults.buttonColors(containerColor = CautionAmber),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("cancel_pre_siren_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Cancel Siren",
                            tint = Color.Black,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (language == AppLanguage.MALAYALAM) {
                                "ഞാൻ ബോധവാനാണ് / റദ്ദാക്കുക"
                            } else {
                                "I'M CONSCIOUS / CANCEL SIREN"
                            },
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Black,
                                color = Color.Black,
                                fontSize = 15.sp
                            )
                        )
                    }
                }
            }

            // Blasting Siren Active Stage
            isSirenActive -> {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Campaign,
                            contentDescription = "Siren Alert",
                            tint = Color.White,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (language == AppLanguage.MALAYALAM) {
                                "സൈറൺ സജീവം (പൂർണ്ണ ശബ്ദത്തിൽ)"
                            } else {
                                "SUB-DEBRIS SIREN ACTIVE (MAX VOL)"
                            },
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Black,
                                color = Color.White,
                                letterSpacing = 1.sp
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = onStopSiren,
                        colors = ButtonDefaults.buttonColors(containerColor = MeshGreen),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                            .testTag("stop_siren_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Stop Siren",
                            tint = Color.Black,
                            modifier = Modifier.size(26.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = if (language == AppLanguage.MALAYALAM) {
                                "ഞാൻ സുരക്ഷിതനാണ് / നിർത്തുക"
                            } else {
                                "I AM SAFE / STOP SIREN"
                            },
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Black,
                                color = Color.Black,
                                fontSize = 16.sp
                            )
                        )
                    }
                }
            }

            // Standby Stage
            else -> {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(TactileSurfaceVariant),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.VolumeUp,
                                contentDescription = "Acoustic Siren",
                                tint = Color(0xFFBAC5D2),
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column {
                            Text(
                                text = if (language == AppLanguage.MALAYALAM) "രക്ഷാ സൈറൺ" else "Acoustic Rescue Siren",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            )
                            Text(
                                text = if (language == AppLanguage.MALAYALAM) "അവശിഷ്ടങ്ങൾ തുളയ്ക്കുന്ന ശബ്ദം" else "Bypasses DND for K-9 & Search Teams",
                                style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFF8B949E))
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF381016))
                                .border(1.dp, EmergencyRed, RoundedCornerShape(8.dp))
                                .clickable(onClick = onStartSiren)
                                .padding(horizontal = 10.dp, vertical = 8.dp)
                                .testTag("trigger_siren_button")
                        ) {
                            Text(
                                text = if (language == AppLanguage.MALAYALAM) "സൈറൺ" else "SOUND SIREN",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Black,
                                    color = Color.White
                                )
                            )
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(TactileSurfaceVariant)
                                .border(1.dp, TactileBorder, RoundedCornerShape(8.dp))
                                .clickable(onClick = onRescuerWakeTest)
                                .padding(horizontal = 10.dp, vertical = 8.dp)
                                .testTag("rescuer_wake_command_button")
                        ) {
                            Text(
                                text = if (language == AppLanguage.MALAYALAM) "പിംഗ്" else "RESCUER PING",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF29B6F6)
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}
