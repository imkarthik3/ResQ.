package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CellTower
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.EmergencyEntity
import com.example.location.GpsState
import com.example.model.AppLanguage
import com.example.ui.theme.CautionAmber
import com.example.ui.theme.EmergencyRed
import com.example.ui.theme.MeshGreen
import com.example.ui.theme.TactileBorder
import com.example.ui.theme.TactileSurface
import com.example.ui.theme.TactileSurfaceVariant
import java.util.Locale

@Composable
fun ActiveSosBanner(
    isBroadcasting: Boolean,
    gpsState: GpsState,
    dutyCyclePhase: String,
    batteryPercent: Int,
    latestAlert: EmergencyEntity?,
    language: AppLanguage = AppLanguage.ENGLISH,
    onStopSos: () -> Unit,
    onAttachMessage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    if (!isBroadcasting) return

    var isCardExpanded by remember { mutableStateOf(false) }
    var messageText by remember(latestAlert?.customNote) {
        mutableStateOf(latestAlert?.customNote ?: "")
    }

    val infiniteTransition = rememberInfiniteTransition(label = "pulse_beacon")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("active_sos_container"),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Persistent Top Banner: "SOS Active & Broadcasting in Background"
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0xFF330B10))
                .border(2.dp, EmergencyRed, RoundedCornerShape(16.dp))
                .padding(14.dp)
                .testTag("active_sos_banner")
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Pulsing Beacon
                        Box(contentAlignment = Alignment.Center) {
                            Box(
                                modifier = Modifier
                                    .size(16.dp)
                                    .scale(pulseScale)
                                    .clip(CircleShape)
                                    .background(EmergencyRed.copy(alpha = 0.4f))
                            )
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(EmergencyRed)
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column {
                            Text(
                                text = if (language == AppLanguage.MALAYALAM) {
                                    "SOS സജീവം - പശ്ചാത്തലത്തിൽ പ്രക്ഷേപണം ചെയ്യുന്നു"
                                } else {
                                    "SOS Active & Broadcasting in Background"
                                },
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Black,
                                    color = Color.White,
                                    fontSize = 15.sp
                                )
                            )
                            Text(
                                text = "Status: ${latestAlert?.status ?: "PENDING_DELIVERY"} • $dutyCyclePhase",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = CautionAmber,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            )
                        }
                    }

                    // Stop / Stand Down Button
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF1E2530))
                            .border(1.dp, Color(0xFF3E4C5E), RoundedCornerShape(8.dp))
                            .clickable(onClick = onStopSos)
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                            .testTag("stop_sos_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.StopCircle,
                                contentDescription = "Stop Broadcast",
                                tint = Color(0xFFFF8A80),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (language == AppLanguage.MALAYALAM) "നിർത്തുക" else "Stand Down",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                    }
                }

                // GPS & Telemetry Snapshot
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF1F070A))
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = "GPS Coordinates",
                            tint = MeshGreen,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = String.format(
                                Locale.US,
                                "%.4f° %s, %.4f° %s (±%dm)",
                                Math.abs(gpsState.latitude),
                                if (gpsState.latitude >= 0) "N" else "S",
                                Math.abs(gpsState.longitude),
                                if (gpsState.longitude >= 0) "E" else "W",
                                gpsState.accuracyMeters.toInt()
                            ),
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = FontFamily.Monospace,
                                color = Color.White,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 11.sp
                            )
                        )
                    }

                    Text(
                        text = "Batt: $batteryPercent% • TTL: ${latestAlert?.ttl ?: 5}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Color(0xFFB0BEC5),
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    )
                }
            }
        }

        // Expandable Message Card: "Add Landmark / Message to Active SOS"
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(TactileSurface)
                .border(1.dp, TactileBorder, RoundedCornerShape(14.dp))
                .padding(12.dp)
                .testTag("expandable_message_card")
        ) {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { isCardExpanded = !isCardExpanded }
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.EditNote,
                            contentDescription = "Add Landmark / Message",
                            tint = CautionAmber,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = if (language == AppLanguage.MALAYALAM) {
                                    "അടയാളം / സന്ദേശം ചേർക്കുക"
                                } else {
                                    "Add Landmark / Message to Active SOS"
                                },
                                style = MaterialTheme.typography.titleSmall.copy(
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            )
                            if (latestAlert?.customNote?.isNotBlank() == true) {
                                Text(
                                    text = "Attached: \"${latestAlert.customNote}\"",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = MeshGreen,
                                        fontSize = 11.sp
                                    ),
                                    maxLines = 1
                                )
                            }
                        }
                    }

                    Icon(
                        imageVector = if (isCardExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = if (isCardExpanded) "Collapse" else "Expand",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }

                AnimatedVisibility(
                    visible = isCardExpanded,
                    enter = expandVertically() + fadeIn(),
                    exit = shrinkVertically() + fadeOut()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 10.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = messageText,
                            onValueChange = { messageText = it },
                            placeholder = {
                                Text(
                                    text = if (language == AppLanguage.MALAYALAM) {
                                        "ഉദാ: മൂന്നാം നിലയിലെ ഗോവണി തകർന്നു, പടിഞ്ഞാറേ വാതിലിനടുത്ത്..."
                                    } else {
                                        "e.g., 3rd Floor staircase collapsed, trapped near west exit..."
                                    },
                                    style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFF7E8B9B))
                                )
                            },
                            minLines = 2,
                            maxLines = 4,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = TactileSurfaceVariant,
                                unfocusedContainerColor = TactileSurfaceVariant,
                                focusedBorderColor = CautionAmber,
                                unfocusedBorderColor = TactileBorder,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("active_sos_message_input")
                        )

                        Button(
                            onClick = {
                                onAttachMessage(messageText)
                                isCardExpanded = false
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CautionAmber,
                                contentColor = Color.Black
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("attach_update_sos_button")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Send,
                                    contentDescription = "Attach & Update SOS",
                                    tint = Color.Black,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (language == AppLanguage.MALAYALAM) "സന്ദേശം അപ്‌ഡേറ്റ് ചെയ്യുക" else "Attach & Update SOS",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Black,
                                        fontSize = 14.sp
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
