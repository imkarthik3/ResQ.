package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.ui.theme.CautionAmber
import com.example.ui.theme.MeshGreen
import com.example.ui.theme.TactileBorder
import com.example.ui.theme.TactileSurface
import com.example.ui.theme.TactileSurfaceVariant

@Composable
fun PanicSafeTopBar(
    currentLanguage: AppLanguage,
    onToggleLanguage: () -> Unit,
    isGpsLocked: Boolean,
    isBleActive: Boolean,
    isPowerSaver: Boolean,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(TactileSurface)
            .border(1.dp, TactileBorder, RoundedCornerShape(16.dp))
            .padding(horizontal = 14.dp, vertical = 10.dp)
            .testTag("panic_safe_top_bar"),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // App Title / Brand identity
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Default.Shield,
                contentDescription = "Off-Grid Disaster Mesh",
                tint = MeshGreen,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "OFF-GRID SOS",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Black,
                        color = Color.White,
                        letterSpacing = 1.sp,
                        fontSize = 14.sp
                    )
                )
                Text(
                    text = if (currentLanguage == AppLanguage.MALAYALAM) "ദുരന്ത അതിജീവന മെഷ്" else "Disaster Survival Mesh",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = Color(0xFF8B949E),
                        fontSize = 10.sp
                    )
                )
            }
        }

        // Live Status Indicators & Bilingual Language Toggle Button
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Status Icons Badge
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(TactileSurfaceVariant)
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // GPS indicator
                Icon(
                    imageVector = Icons.Default.GpsFixed,
                    contentDescription = "GPS status",
                    tint = if (isGpsLocked) MeshGreen else CautionAmber,
                    modifier = Modifier.size(16.dp)
                )

                // BLE Mesh indicator
                Icon(
                    imageVector = Icons.Default.Sensors,
                    contentDescription = "BLE Radio Mesh",
                    tint = if (isBleActive) MeshGreen else Color(0xFF6E7E91),
                    modifier = Modifier.size(16.dp)
                )
            }

            // High-Contrast Bilingual Language Switcher Button (EN | മലയാളം)
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF1E293B))
                    .border(1.5.dp, Color(0xFF38BDF8), RoundedCornerShape(10.dp))
                    .clickable(onClick = onToggleLanguage)
                    .padding(horizontal = 10.dp, vertical = 7.dp)
                    .testTag("language_toggle_button"),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Language,
                        contentDescription = "Language toggle",
                        tint = Color(0xFF38BDF8),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (currentLanguage == AppLanguage.ENGLISH) "മലയാളം" else "ENGLISH",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Black,
                            color = Color.White,
                            fontSize = 12.sp
                        )
                    )
                }
            }
        }
    }
}
