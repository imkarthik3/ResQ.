package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.TriageFlag
import com.example.ui.theme.CautionAmber
import com.example.ui.theme.EmergencyRed
import com.example.ui.theme.TactileBorder
import com.example.ui.theme.TactileSurface
import com.example.ui.theme.TactileSurfaceVariant

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TriageChipsSection(
    selectedFlags: Set<TriageFlag>,
    headcount: Int,
    language: AppLanguage = AppLanguage.ENGLISH,
    onToggleFlag: (TriageFlag) -> Unit,
    onIncrementHeadcount: () -> Unit,
    onDecrementHeadcount: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(TactileSurface)
            .border(1.dp, TactileBorder, RoundedCornerShape(16.dp))
            .padding(14.dp)
            .testTag("triage_chips_section")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            val titleText = if (language == AppLanguage.MALAYALAM) {
                "അടിയന്തര സാഹചര്യങ്ങൾ (തിരഞ്ഞെടുക്കുക)"
            } else {
                "EMERGENCY TRIAGE STATUS (MULTI-SELECT)"
            }

            Text(
                text = titleText,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Black,
                    color = Color(0xFF9EABB8),
                    letterSpacing = 1.sp
                )
            )

            if (selectedFlags.isNotEmpty()) {
                Text(
                    text = "${selectedFlags.size} SELECTED",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = EmergencyRed,
                        letterSpacing = 0.5.sp
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Multi-selectable 9-chip grid
        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            maxItemsInEachRow = 2
        ) {
            TriageFlag.entries.forEach { flag ->
                val isSelected = selectedFlags.contains(flag)
                TriageChipItem(
                    flag = flag,
                    isSelected = isSelected,
                    language = language,
                    onClick = { onToggleFlag(flag) },
                    modifier = Modifier.weight(1f, fill = true)
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Headcount Stepper: [-] 1 Person [+]
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(TactileSurfaceVariant)
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Group,
                    contentDescription = "Headcount",
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = if (language == AppLanguage.MALAYALAM) "ആളുകളുടെ എണ്ണം" else "People Together",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    )
                    Text(
                        text = if (language == AppLanguage.MALAYALAM) "1 മുതൽ 15 പേർ വരെ" else "1 to 15 Survivors",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = Color(0xFF8B949E),
                            fontSize = 11.sp
                        )
                    )
                }
            }

            // Stepper controls
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(if (headcount > 1) Color(0xFF263242) else Color(0xFF1B232E))
                        .clickable(enabled = headcount > 1, onClick = onDecrementHeadcount),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Remove,
                        contentDescription = "Decrease headcount",
                        tint = if (headcount > 1) Color.White else Color(0xFF536273),
                        modifier = Modifier.size(20.dp)
                    )
                }

                Text(
                    text = if (language == AppLanguage.MALAYALAM) {
                        "$headcount ആൾ"
                    } else {
                        "$headcount Person${if (headcount > 1) "s" else ""}"
                    },
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Black,
                        color = Color.White,
                        fontSize = 15.sp
                    ),
                    modifier = Modifier.padding(horizontal = 4.dp)
                )

                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(if (headcount < 15) Color(0xFF263242) else Color(0xFF1B232E))
                        .clickable(enabled = headcount < 15, onClick = onIncrementHeadcount),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Increase headcount",
                        tint = if (headcount < 15) Color.White else Color(0xFF536273),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun TriageChipItem(
    flag: TriageFlag,
    isSelected: Boolean,
    language: AppLanguage,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val borderColor by animateColorAsState(
        targetValue = when {
            isSelected && (flag == TriageFlag.CRITICAL_EMERGENCY || flag == TriageFlag.DROWNING || flag == TriageFlag.TRAPPED) -> EmergencyRed
            isSelected -> CautionAmber
            else -> Color(0xFF263242)
        },
        label = "chip_border"
    )

    val bgColor by animateColorAsState(
        targetValue = when {
            isSelected && (flag == TriageFlag.CRITICAL_EMERGENCY || flag == TriageFlag.DROWNING || flag == TriageFlag.TRAPPED) -> Color(0xFF4A121A)
            isSelected -> Color(0xFF382A0E)
            else -> TactileSurfaceVariant
        },
        label = "chip_bg"
    )

    Box(
        modifier = modifier
            .height(54.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(bgColor)
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = borderColor,
                shape = RoundedCornerShape(10.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp)
            .testTag("chip_${flag.name.lowercase()}"),
        contentAlignment = Alignment.CenterStart
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Start
        ) {
            Text(
                text = flag.iconEmoji,
                fontSize = 18.sp
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = flag.getLabel(language),
                style = MaterialTheme.typography.labelMedium.copy(
                    color = if (isSelected) Color.White else Color(0xFFBAC5D2),
                    fontWeight = if (isSelected) FontWeight.Black else FontWeight.Bold,
                    fontSize = 12.sp,
                    lineHeight = 14.sp
                ),
                maxLines = 2
            )
        }
    }
}
