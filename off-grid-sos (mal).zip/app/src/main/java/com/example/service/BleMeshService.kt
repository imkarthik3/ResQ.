package com.example.service

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.le.AdvertiseCallback
import android.bluetooth.le.AdvertiseData
import android.bluetooth.le.AdvertiseSettings
import android.bluetooth.le.BluetoothLeAdvertiser
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanRecord
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.BatteryManager
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.audio.SirenManager
import com.example.data.EmergencyDatabase
import com.example.model.SosPacket
import com.example.repository.MeshRepository
import com.example.serializer.PacketSerializer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class BleMeshService : Service() {

    companion object {
        private const val TAG = "BleMeshService"
        const val NOTIFICATION_ID = 1001
        const val CHANNEL_ID = "mesh_sos_foreground_channel"
        const val MANUFACTURER_ID = 0xFFFF // Custom Disaster Mesh Identifier

        // Custom Actions
        const val ACTION_START_BROADCAST = "com.example.action.START_BROADCAST"
        const val ACTION_STOP_BROADCAST = "com.example.action.STOP_BROADCAST"
        const val ACTION_UPDATE_PAYLOAD = "com.example.action.UPDATE_PAYLOAD"
        const val ACTION_TOGGLE_POWER_SAVER = "com.example.action.TOGGLE_POWER_SAVER"
        const val ACTION_SET_SLEEP_INTERVAL = "com.example.action.SET_SLEEP_INTERVAL"
        const val ACTION_TRIGGER_RESCUER_SIREN = "com.example.action.TRIGGER_RESCUER_SIREN"
        const val EXTRA_INTERVAL_MINUTES = "extra_interval_minutes"
        const val EXTRA_PAYLOAD_BYTES = "extra_payload_bytes"

        // Public Service State Flows
        private val _isBroadcasting = MutableStateFlow(false)
        val isBroadcasting: StateFlow<Boolean> = _isBroadcasting.asStateFlow()

        private val _isPowerSaverMode = MutableStateFlow(false)
        val isPowerSaverMode: StateFlow<Boolean> = _isPowerSaverMode.asStateFlow()

        private val _sleepIntervalMinutes = MutableStateFlow(5)
        val sleepIntervalMinutes: StateFlow<Int> = _sleepIntervalMinutes.asStateFlow()

        private val _dutyCyclePhase = MutableStateFlow("Radio Standby")
        val dutyCyclePhase: StateFlow<String> = _dutyCyclePhase.asStateFlow()

        private val _nearbyNodesCount = MutableStateFlow(0)
        val nearbyNodesCount: StateFlow<Int> = _nearbyNodesCount.asStateFlow()

        private val _relayedPacketsCount = MutableStateFlow(0)
        val relayedPacketsCount: StateFlow<Int> = _relayedPacketsCount.asStateFlow()

        private val _batteryLevel = MutableStateFlow(100)
        val batteryLevel: StateFlow<Int> = _batteryLevel.asStateFlow()

        private val _autoPowerSaverAlert = MutableStateFlow(false)
        val autoPowerSaverAlert: StateFlow<Boolean> = _autoPowerSaverAlert.asStateFlow()

        // 3-Tier Dynamic Duty-Cycling Profile:
        // Tier 1 (>75%): 30s active, 1m sleep
        // Tier 2 (25-75%): 30s active, 5m deep sleep
        // Tier 3 (<25%): 15s active, 15m deep sleep + last gasp commit
        private val _currentDutyTier = MutableStateFlow("Tier 1 (>75%)")
        val currentDutyTier: StateFlow<String> = _currentDutyTier.asStateFlow()

        fun setPowerSaverMode(enabled: Boolean) {
            _isPowerSaverMode.value = enabled
        }

        fun setSleepInterval(minutes: Int) {
            _sleepIntervalMinutes.value = minutes
        }

        fun dismissBatteryAlert() {
            _autoPowerSaverAlert.value = false
        }
    }

    private val binder = LocalBinder()
    inner class LocalBinder : Binder() {
        fun getService(): BleMeshService = this@BleMeshService
    }

    private val serviceScope = CoroutineScope(Dispatchers.IO + Job())
    private var dutyCycleJob: Job? = null
    private var relayWorkerJob: Job? = null

    private var wakeLock: PowerManager.WakeLock? = null
    private var bluetoothAdapter: BluetoothAdapter? = null
    private var advertiser: BluetoothLeAdvertiser? = null
    private var scanner: BluetoothLeScanner? = null

    private lateinit var repository: MeshRepository
    private var currentActivePayload: ByteArray? = null

    // Track peer proximity duration for Layer 2 Extended Text opportunistic sync
    // Map of packetHash -> firstSeenTimestamp
    private val peerFirstSeenMap = mutableMapOf<Long, Long>()
    private val peerLastSeenMap = mutableMapOf<Long, Long>()
    private val peerNarrativeSynced = mutableSetOf<Long>()

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            intent?.let {
                val level = it.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale = it.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
                if (level >= 0 && scale > 0) {
                    val pct = (level * 100) / scale
                    _batteryLevel.value = pct

                    // Check for Last-Gasp flash memory state commit when battery < 25%
                    if (pct < 25) {
                        performLastGaspStateCommit()
                    }

                    if (pct < 60 && !_isPowerSaverMode.value) {
                        _isPowerSaverMode.value = true
                        _autoPowerSaverAlert.value = true
                    }
                    restartDutyCycle()
                }
            }
        }
    }

    private val advertiseCallback = object : AdvertiseCallback() {
        override fun onStartSuccess(settingsInEffect: AdvertiseSettings?) {
            Log.d(TAG, "BLE Mesh Advertising successfully started")
        }

        override fun onStartFailure(errorCode: Int) {
            Log.e(TAG, "BLE Mesh Advertising failed with code: $errorCode")
        }
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult?) {
            handleScanResult(result)
        }

        override fun onBatchScanResults(results: MutableList<ScanResult>?) {
            results?.forEach { handleScanResult(it) }
        }

        override fun onScanFailed(errorCode: Int) {
            Log.e(TAG, "BLE Mesh Scanning failed: $errorCode")
        }
    }

    override fun onCreate() {
        super.onCreate()
        val db = EmergencyDatabase.getInstance(applicationContext)
        repository = MeshRepository(db)

        val bluetoothManager = getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        bluetoothAdapter = bluetoothManager?.adapter

        val powerManager = getSystemService(Context.POWER_SERVICE) as? PowerManager
        wakeLock = powerManager?.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "OffGridMesh::RadioWakeLock"
        )?.apply {
            setReferenceCounted(false)
        }

        createNotificationChannel()
        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))

        // Initial battery query
        val bm = getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
        val initialBat = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: 100
        _batteryLevel.value = initialBat
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = createNotification("Mesh Radio Standby")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION or ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        when (intent?.action) {
            ACTION_START_BROADCAST -> {
                val payload = intent.getByteArrayExtra(EXTRA_PAYLOAD_BYTES)
                if (payload != null) {
                    currentActivePayload = payload
                }
                startBroadcastingMesh()
            }
            ACTION_STOP_BROADCAST -> {
                stopBroadcastingMesh()
            }
            ACTION_UPDATE_PAYLOAD -> {
                val payload = intent.getByteArrayExtra(EXTRA_PAYLOAD_BYTES)
                if (payload != null) {
                    currentActivePayload = payload
                    if (_isBroadcasting.value) {
                        restartAdvertisingWithNewPayload()
                    }
                }
            }
            ACTION_TOGGLE_POWER_SAVER -> {
                _isPowerSaverMode.value = !_isPowerSaverMode.value
                restartDutyCycle()
            }
            ACTION_SET_SLEEP_INTERVAL -> {
                val minutes = intent.getIntExtra(EXTRA_INTERVAL_MINUTES, 5)
                _sleepIntervalMinutes.value = minutes
                restartDutyCycle()
            }
            ACTION_TRIGGER_RESCUER_SIREN -> {
                // Rescuer node pinging acoustic wake broadcast
                val wakePayload = PacketSerializer.createWakeSirenPacket(System.currentTimeMillis())
                sendSingleBurst(wakePayload)
            }
        }

        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onDestroy() {
        stopBroadcastingMesh()
        try {
            unregisterReceiver(batteryReceiver)
        } catch (e: Exception) {
            Log.w(TAG, "Battery receiver unregister error: ${e.message}")
        }
        serviceScope.launch {
            wakeLock?.let {
                if (it.isHeld) it.release()
            }
        }
        super.onDestroy()
    }

    private fun startBroadcastingMesh() {
        _isBroadcasting.value = true

        try {
            if (wakeLock?.isHeld != true) {
                wakeLock?.acquire(24 * 60 * 60 * 1000L) // 24 hours persistent partial wakelock
            }
        } catch (e: Exception) {
            Log.w(TAG, "WakeLock acquire error: ${e.message}")
        }

        advertiser = bluetoothAdapter?.bluetoothLeAdvertiser
        scanner = bluetoothAdapter?.bluetoothLeScanner

        startDutyCycleLoop()
        startPeriodicRelayWorker()
        updateNotification("SOS Broadcasting & Mesh Active")
    }

    private fun stopBroadcastingMesh() {
        _isBroadcasting.value = false
        dutyCycleJob?.cancel()
        relayWorkerJob?.cancel()
        stopAdvertising()
        stopScanning()

        try {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }
        } catch (e: Exception) {
            Log.w(TAG, "WakeLock release error: ${e.message}")
        }

        _dutyCyclePhase.value = "Radio Standby"
        updateNotification("Mesh Radio Standby")
    }

    private fun restartDutyCycle() {
        if (_isBroadcasting.value) {
            dutyCycleJob?.cancel()
            startDutyCycleLoop()
        }
    }

    /**
     * 3-Tier Dynamic Duty-Cycling Engine:
     * - Battery > 75%: 30s active scan/broadcast, 1m sleep.
     * - Battery 25% - 75%: 30s active scan/broadcast, 5m deep sleep.
     * - Battery < 25%: 15s active scan/broadcast, 15m deep sleep, plus Last-Gasp flash commit.
     */
    private fun startDutyCycleLoop() {
        dutyCycleJob = serviceScope.launch {
            while (isActive && _isBroadcasting.value) {
                val battery = _batteryLevel.value
                val activeBurstMillis: Long
                val sleepMillis: Long
                val tierName: String

                when {
                    battery > 75 -> {
                        activeBurstMillis = 30_000L
                        sleepMillis = 60_000L // 1 min sleep
                        tierName = "Tier 1: Normal (>75%) - 30s Tx / 1m Sleep"
                    }
                    battery in 25..75 -> {
                        activeBurstMillis = 30_000L
                        sleepMillis = if (_isPowerSaverMode.value) {
                            _sleepIntervalMinutes.value * 60 * 1000L
                        } else {
                            5 * 60 * 1000L // 5 min sleep
                        }
                        tierName = "Tier 2: Economy (25-75%) - 30s Tx / 5m Sleep"
                    }
                    else -> {
                        activeBurstMillis = 15_000L // 15s active
                        sleepMillis = 15 * 60 * 1000L // 15 min deep sleep
                        tierName = "Tier 3: Last-Gasp (<25%) - 15s Tx / 15m Sleep"
                    }
                }

                _currentDutyTier.value = tierName

                // Phase 1: Active Scan & Broadcast Burst
                _dutyCyclePhase.value = "Active Radio Burst (${activeBurstMillis / 1000}s)"
                startAdvertising()
                startScanning()
                delay(activeBurstMillis)

                // Phase 2: Deep Radio Sleep
                val sleepMinutes = (sleepMillis / 60000L).coerceAtLeast(1)
                _dutyCyclePhase.value = "Deep Radio Sleep (${sleepMinutes}m)"
                stopAdvertising()
                stopScanning()
                delay(sleepMillis)
            }
        }
    }

    /**
     * Last-Gasp flash-memory state commit when battery drops below 25%.
     */
    private fun performLastGaspStateCommit() {
        serviceScope.launch {
            try {
                Log.w(TAG, "Executing Last-Gasp critical state flash commit to Room DB...")
                repository.pruneOldPackets(100)
                val prefs = getSharedPreferences("mesh_sos_prefs", Context.MODE_PRIVATE)
                prefs.edit()
                    .putLong("last_gasp_timestamp", System.currentTimeMillis())
                    .putInt("last_gasp_battery", _batteryLevel.value)
                    .commit() // Synchronous flash commit
            } catch (e: Exception) {
                Log.e(TAG, "Last gasp commit error", e)
            }
        }
    }

    private fun startPeriodicRelayWorker() {
        relayWorkerJob = serviceScope.launch {
            while (isActive && _isBroadcasting.value) {
                delay(20_000L)
                try {
                    val queue = repository.getRelayPackets()
                    for (entity in queue) {
                        if (!isActive) break
                        if (entity.ttl > 0 && !entity.isSelfCreated) {
                            sendSingleBurst(entity.rawBytes)
                            repository.markRelayed(entity.packetHash)
                            _relayedPacketsCount.value += 1
                            delay(1_500L)
                        }
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Relay queue error: ${e.message}")
                }
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun startAdvertising() {
        val adv = advertiser ?: bluetoothAdapter?.bluetoothLeAdvertiser ?: return
        val payload = currentActivePayload ?: return

        try {
            val settings = AdvertiseSettings.Builder()
                .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_POWER)
                .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_HIGH)
                .setConnectable(false)
                .setTimeout(0)
                .build()

            val data = AdvertiseData.Builder()
                .addManufacturerData(MANUFACTURER_ID, payload)
                .setIncludeTxPowerLevel(false)
                .setIncludeDeviceName(false)
                .build()

            adv.startAdvertising(settings, data, advertiseCallback)
        } catch (e: SecurityException) {
            Log.w(TAG, "Missing BLE advertise permission: ${e.message}")
        } catch (e: Exception) {
            Log.e(TAG, "Failed startAdvertising", e)
        }
    }

    @SuppressLint("MissingPermission")
    private fun stopAdvertising() {
        try {
            advertiser?.stopAdvertising(advertiseCallback)
        } catch (e: Exception) {
            Log.w(TAG, "Error stopping advertising: ${e.message}")
        }
    }

    private fun restartAdvertisingWithNewPayload() {
        stopAdvertising()
        startAdvertising()
    }

    @SuppressLint("MissingPermission")
    private fun startScanning() {
        val sc = scanner ?: bluetoothAdapter?.bluetoothLeScanner ?: return
        try {
            val filter = ScanFilter.Builder()
                .setManufacturerData(MANUFACTURER_ID, ByteArray(0))
                .build()

            val settings = ScanSettings.Builder()
                .setScanMode(ScanSettings.SCAN_MODE_LOW_POWER)
                .setReportDelay(0)
                .build()

            sc.startScan(listOf(filter), settings, scanCallback)
        } catch (e: SecurityException) {
            Log.w(TAG, "Missing BLE scan permission: ${e.message}")
        } catch (e: Exception) {
            Log.e(TAG, "Failed startScanning", e)
        }
    }

    @SuppressLint("MissingPermission")
    private fun stopScanning() {
        try {
            scanner?.stopScan(scanCallback)
        } catch (e: Exception) {
            Log.w(TAG, "Error stopping scanning: ${e.message}")
        }
    }

    @SuppressLint("MissingPermission")
    private fun sendSingleBurst(payload: ByteArray) {
        val adv = advertiser ?: bluetoothAdapter?.bluetoothLeAdvertiser ?: return
        try {
            val settings = AdvertiseSettings.Builder()
                .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_BALANCED)
                .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_HIGH)
                .setConnectable(false)
                .setTimeout(1200)
                .build()

            val data = AdvertiseData.Builder()
                .addManufacturerData(MANUFACTURER_ID, payload)
                .setIncludeTxPowerLevel(false)
                .setIncludeDeviceName(false)
                .build()

            adv.startAdvertising(settings, data, object : AdvertiseCallback() {
                override fun onStartSuccess(settingsInEffect: AdvertiseSettings?) {
                    Log.d(TAG, "Burst packet broadcasted successfully")
                }
            })
        } catch (e: Exception) {
            Log.w(TAG, "Burst advertising error: ${e.message}")
        }
    }

    private fun handleScanResult(result: ScanResult?) {
        val scanRecord = result?.scanRecord ?: return
        val raw = scanRecord.getManufacturerSpecificData(MANUFACTURER_ID) ?: return

        if (raw.size < PacketSerializer.PACKET_SIZE) return

        serviceScope.launch {
            try {
                val (packet, isNew) = repository.handleReceivedPacket(raw)
                if (packet != null) {
                    val now = System.currentTimeMillis()
                    peerLastSeenMap[packet.packetHash] = now
                    if (!peerFirstSeenMap.containsKey(packet.packetHash)) {
                        peerFirstSeenMap[packet.packetHash] = now
                    }

                    pruneExpiredPeers()
                    _nearbyNodesCount.value = peerLastSeenMap.size

                    // Layer 2: Extended Text Proximity Opportunistic Direct Sync
                    // When bystander or rescuer node remains within proximity for >5 seconds,
                    // transfer the full text narrative over opportunistic direct connection.
                    val firstSeen = peerFirstSeenMap[packet.packetHash] ?: now
                    if ((now - firstSeen >= 5000L) && !peerNarrativeSynced.contains(packet.packetHash)) {
                        peerNarrativeSynced.add(packet.packetHash)
                        opportunisticDirectNarrativeSync(packet.packetHash)
                    }

                    // Check for Rescuer Acoustic Wake Command with Safe 5s Pre-Vibration
                    if (packet.protocolVersion == SosPacket.PROTOCOL_WAKE_SIREN) {
                        Log.i(TAG, "AUTHENTICATED WAKE_SIREN RECEIVED FROM SEARCH-AND-RESCUE TEAM!")
                        // Triggers 5-second pre-vibration safety sequence
                        SirenManager.triggerSafeSirenSequence(this@BleMeshService)
                    } else if (isNew && packet.ttl > 1) {
                        // Store-Carry-Forward Proximity Relay
                        val relayPacket = packet.copy(ttl = (packet.ttl - 1).toByte())
                        val serializedRelay = PacketSerializer.serialize(relayPacket)
                        sendSingleBurst(serializedRelay)
                        _relayedPacketsCount.value += 1
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error handling mesh scan result", e)
            }
        }
    }

    /**
     * Opportunistic direct narrative sync for extended text details (Layer 2).
     */
    private fun opportunisticDirectNarrativeSync(targetHash: Long) {
        serviceScope.launch {
            try {
                val mySelfAlert = repository.getLatestSelfAlert()
                if (mySelfAlert != null && mySelfAlert.customNote.isNotBlank()) {
                    Log.i(TAG, "Target node 0x${java.lang.Long.toHexString(targetHash)} in proximity >5s. Initiating direct narrative transfer: \"${mySelfAlert.customNote}\"")
                    // Mark direct synchronization in database
                    repository.updateAlertStatus(mySelfAlert.packetHash, com.example.data.EmergencyEntity.STATUS_DELIVERED)
                }
            } catch (e: Exception) {
                Log.w(TAG, "Direct narrative sync error: ${e.message}")
            }
        }
    }

    private fun pruneExpiredPeers() {
        val now = System.currentTimeMillis()
        val iterator = peerLastSeenMap.entries.iterator()
        while (iterator.hasNext()) {
            val entry = iterator.next()
            if (now - entry.value > 120_000L) {
                iterator.remove()
                peerFirstSeenMap.remove(entry.key)
            }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Emergency Off-Grid Mesh Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Maintains offline BLE Mesh Radio and acoustic survival beacon"
                setShowBadge(false)
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            manager?.createNotificationChannel(channel)
        }
    }

    private fun createNotification(statusText: String): Notification {
        val launchIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Off-Grid Disaster Mesh SOS")
            .setContentText(statusText)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setOngoing(true)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun updateNotification(statusText: String) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        manager?.notify(NOTIFICATION_ID, createNotification(statusText))
    }
}
