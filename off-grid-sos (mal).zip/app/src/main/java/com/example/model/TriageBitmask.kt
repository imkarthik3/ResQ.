package com.example.model

/**
 * Supported UI display languages for the bilingual panic-safe interface.
 */
enum class AppLanguage(val code: String, val label: String) {
    ENGLISH("EN", "English"),
    MALAYALAM("ML", "മലയാളം")
}

/**
 * Pre-defined Emergency Triage Flags with bilingual labels (English & Malayalam).
 * Stored as a 16-bit bitmask (Bytes 17-18 of the 30-byte BLE frame).
 */
enum class TriageFlag(
    val bitIndex: Int,
    val enLabel: String,
    val mlLabel: String,
    val iconEmoji: String
) {
    DROWNING(0, "Drowning / Water Rising", "വെള്ളപ്പൊക്കം / മുങ്ങുന്നു", "🌊"),
    TRAPPED(1, "Trapped Under Debris", "അവശിഷ്ടങ്ങൾക്കടിയിൽ കുടുങ്ങി", "🧱"),
    CRITICAL_EMERGENCY(2, "Critical / Unconscious", "അത്യാഹിതം / ബോധരഹിതൻ", "🚨"),
    INJURED_BLEEDING(3, "Injured / Bleeding", "പരിക്കേറ്റു / രക്തസ്രാവം", "🩸"),
    PREGNANT(4, "Pregnant Woman", "ഗർഭിണിയായ സ്ത്രീ", "🤰"),
    BABIES_INFANTS(5, "Infants / Children", "കുട്ടികൾ", "👶"),
    ELDERLY(6, "Elderly / Senior", "പ്രായമായവർ", "🧓"),
    MEDICINE_INSULIN(7, "Medicine / Insulin Needed", "മരുന്ന് / ഇൻസുലിൻ ആവശ്യം", "💊"),
    FOOD_WATER(8, "Food & Water Needed", "ഭക്ഷണം / ശുദ്ധജലം", "🍞");

    val bitmaskValue: Int get() = 1 shl bitIndex

    fun getLabel(language: AppLanguage): String = when (language) {
        AppLanguage.ENGLISH -> enLabel
        AppLanguage.MALAYALAM -> mlLabel
    }

    // Default backward compatibility display name
    val displayName: String get() = enLabel

    companion object {
        fun fromBitIndex(index: Int): TriageFlag? {
            return entries.firstOrNull { it.bitIndex == index }
        }
    }
}

/**
 * Helper functions for 16-bit Triage bitmask conversion and query.
 */
object TriageBitmaskHelper {

    /**
     * Packs a collection of selected TriageFlags into a 16-bit Short bitmask.
     */
    fun toBitmask(flags: Set<TriageFlag>): Short {
        var mask = 0
        for (flag in flags) {
            mask = mask or flag.bitmaskValue
        }
        return mask.toShort()
    }

    /**
     * Unpacks a 16-bit Short bitmask into a Set of TriageFlags.
     */
    fun fromBitmask(bitmask: Short): Set<TriageFlag> {
        val maskInt = bitmask.toInt() and 0xFFFF
        val set = mutableSetOf<TriageFlag>()
        for (flag in TriageFlag.entries) {
            if ((maskInt and flag.bitmaskValue) != 0) {
                set.add(flag)
            }
        }
        return set
    }

    /**
     * Checks if a specific flag is active within a 16-bit bitmask.
     */
    fun hasFlag(bitmask: Short, flag: TriageFlag): Boolean {
        return ((bitmask.toInt() and 0xFFFF) and flag.bitmaskValue) != 0
    }

    /**
     * Returns a human-readable list of active triage labels in the specified language.
     */
    fun describeBitmask(bitmask: Short, language: AppLanguage = AppLanguage.ENGLISH): List<String> {
        return fromBitmask(bitmask).map { "${it.iconEmoji} ${it.getLabel(language)}" }
    }
}
