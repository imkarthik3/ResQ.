package com.example.model

/**
 * Represents the 30-byte compact binary emergency distress mesh packet.
 */
data class SosPacket(
    val protocolVersion: Byte = PROTOCOL_SOS,
    val packetHash: Long, // 8 bytes unique hash for deduplication
    val latitude: Float, // Float32
    val longitude: Float, // Float32
    val triageFlags: Short = 0, // 16-bit bitmask (Bytes 17-18)
    val headcount: Int = 1, // 1-15 (4 bits)
    val batteryPercent: Int = 100, // 0-100% (scaled to 4 bits 0-15)
    val ttl: Byte = DEFAULT_TTL, // Hop count (default 5)
    val timestampSeconds: Long = System.currentTimeMillis() / 1000, // Epoch seconds (4 bytes)
    val checksum: ByteArray = ByteArray(5), // 5 bytes verification (Bytes 25-29)
    val customNote: String = "" // Optional local detail
) {
    companion object {
        const val PROTOCOL_SOS: Byte = 0x01
        const val PROTOCOL_WAKE_SIREN: Byte = 0x02
        const val DEFAULT_TTL: Byte = 5
    }

    val activeFlags: Set<TriageFlag> get() = TriageBitmaskHelper.fromBitmask(triageFlags)

    fun hasFlag(flag: TriageFlag): Boolean = TriageBitmaskHelper.hasFlag(triageFlags, flag)

    val isMedicalUrgent: Boolean get() = hasFlag(TriageFlag.CRITICAL_EMERGENCY) || hasFlag(TriageFlag.INJURED_BLEEDING)
    val isDrowning: Boolean get() = hasFlag(TriageFlag.DROWNING)
    val isTrapped: Boolean get() = hasFlag(TriageFlag.TRAPPED)
    val needsMedicine: Boolean get() = hasFlag(TriageFlag.MEDICINE_INSULIN)
    val needsFoodWater: Boolean get() = hasFlag(TriageFlag.FOOD_WATER)

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false
        other as SosPacket
        return packetHash == other.packetHash && ttl == other.ttl
    }

    override fun hashCode(): Int {
        return packetHash.hashCode()
    }
}

