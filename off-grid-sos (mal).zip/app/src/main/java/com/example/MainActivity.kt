package com.example

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.AppLanguage
import com.example.ui.MeshViewModel
import com.example.ui.components.ActiveSosBanner
import com.example.ui.components.AutoPowerSaverAlertBanner
import com.example.ui.components.BatterySaverToggleCard
import com.example.ui.components.MeshActivityCard
import com.example.ui.components.MeshPacketsBottomSheet
import com.example.ui.components.PanicSafeTopBar
import com.example.ui.components.PanicSosButton
import com.example.ui.components.PermissionExplainerCard
import com.example.ui.components.SirenControlBar
import com.example.ui.components.SleepIntervalBottomSheet
import com.example.ui.components.StatusTopCard
import com.example.ui.components.TriageChipsSection
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.TacticalBlack

class MainActivity : ComponentActivity() {

    private val viewModel: MeshViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                MeshSosScreen(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MeshSosScreen(viewModel: MeshViewModel) {
    val context = LocalContext.current

    val currentLanguage by viewModel.currentLanguage.collectAsStateWithLifecycle()
    val gpsState by viewModel.gpsState.collectAsStateWithLifecycle()
    val isBroadcasting by viewModel.isBroadcasting.collectAsStateWithLifecycle()
    val isPowerSaverMode by viewModel.isPowerSaverMode.collectAsStateWithLifecycle()
    val sleepIntervalMinutes by viewModel.sleepIntervalMinutes.collectAsStateWithLifecycle()
    val dutyCyclePhase by viewModel.dutyCyclePhase.collectAsStateWithLifecycle()
    val nearbyNodesCount by viewModel.nearbyNodesCount.collectAsStateWithLifecycle()
    val relayedPacketsCount by viewModel.relayedPacketsCount.collectAsStateWithLifecycle()
    val batteryLevel by viewModel.batteryLevel.collectAsStateWithLifecycle()
    val autoPowerSaverAlert by viewModel.autoPowerSaverAlert.collectAsStateWithLifecycle()
    val batteryLifeEstimate by viewModel.batteryLifeEstimate.collectAsStateWithLifecycle()
    val isSirenActive by viewModel.isSirenActive.collectAsStateWithLifecycle()
    val isPreVibrating by viewModel.isPreVibrating.collectAsStateWithLifecycle()
    val countdownSeconds by viewModel.countdownSecondsRemaining.collectAsStateWithLifecycle()
    val cachedPackets by viewModel.cachedPackets.collectAsStateWithLifecycle()
    val latestSelfAlert by viewModel.latestSelfAlert.collectAsStateWithLifecycle()

    val selectedTriageFlags by viewModel.selectedTriageFlags.collectAsStateWithLifecycle()
    val headcount by viewModel.headcount.collectAsStateWithLifecycle()

    var showPacketsSheet by remember { mutableStateOf(false) }
    var showSleepConfigSheet by remember { mutableStateOf(false) }

    // Required runtime permissions
    val requiredPermissions = remember {
        val list = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            list.add(Manifest.permission.BLUETOOTH_SCAN)
            list.add(Manifest.permission.BLUETOOTH_ADVERTISE)
            list.add(Manifest.permission.BLUETOOTH_CONNECT)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            list.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        list.toTypedArray()
    }

    var allPermissionsGranted by remember {
        mutableStateOf(
            requiredPermissions.all {
                ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
            }
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val granted = results.values.all { it }
        allPermissionsGranted = granted
        viewModel.setPermissionsGranted(granted)
    }

    LaunchedEffect(Unit) {
        if (!allPermissionsGranted) {
            permissionLauncher.launch(requiredPermissions)
        } else {
            viewModel.setPermissionsGranted(true)
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        containerColor = TacticalBlack
    ) { innerPadding ->
        val statusBarPadding = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(TacticalBlack)
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 640.dp)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp)
                    .padding(top = statusBarPadding + 8.dp, bottom = 28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Section 0: Bilingual Panic-Safe Top Bar (Instant EN | മലയാളം Toggle & Status)
                PanicSafeTopBar(
                    currentLanguage = currentLanguage,
                    onToggleLanguage = { viewModel.toggleLanguage() },
                    isGpsLocked = gpsState.isFixed || gpsState.isChipsetSleeping,
                    isBleActive = isBroadcasting,
                    isPowerSaver = isPowerSaverMode
                )

                // Section 1: Live Status Bar Card (GPS Satellite count, Standby coords, Battery Life)
                StatusTopCard(
                    gpsState = gpsState,
                    isBroadcasting = isBroadcasting,
                    batteryPercent = batteryLevel,
                    batteryLifeEstimate = batteryLifeEstimate,
                    powerSaverMode = isPowerSaverMode,
                    dutyCyclePhase = dutyCyclePhase,
                    nearbyNodesCount = nearbyNodesCount,
                    language = currentLanguage,
                    onCardClick = { showPacketsSheet = true }
                )

                // Frictionless Permissions Explainer Card (if not yet granted)
                if (!allPermissionsGranted) {
                    PermissionExplainerCard(
                        onRequestPermissions = {
                            permissionLauncher.launch(requiredPermissions)
                        }
                    )
                }

                // Automatic Battery Saver Notification (when drops <60%)
                if (autoPowerSaverAlert) {
                    AutoPowerSaverAlertBanner(
                        batteryLevel = batteryLevel,
                        onDismiss = { viewModel.dismissBatteryAlert() }
                    )
                }

                // Section 2: Persistent Active SOS Banner & Landmark Attachment (when broadcasting)
                if (isBroadcasting) {
                    ActiveSosBanner(
                        isBroadcasting = isBroadcasting,
                        gpsState = gpsState,
                        dutyCyclePhase = dutyCyclePhase,
                        batteryPercent = batteryLevel,
                        latestAlert = latestSelfAlert,
                        language = currentLanguage,
                        onStopSos = { viewModel.stopSosBroadcast() },
                        onAttachMessage = { viewModel.attachAndUpdateSos(it) }
                    )
                }

                // Section 3: Centered Massive 1-Tap SOS Button with Tactile Haptic Feedback
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    PanicSosButton(
                        isBroadcasting = isBroadcasting,
                        language = currentLanguage,
                        onSosClick = {
                            triggerTactileHapticFeedback(context)
                            if (!allPermissionsGranted) {
                                permissionLauncher.launch(requiredPermissions)
                            } else {
                                viewModel.toggleSosBroadcast()
                            }
                        }
                    )
                }

                // Section 4: Expanded 9-Chip Triage Grid & Headcount Stepper (One-Thumb Reachable)
                TriageChipsSection(
                    selectedFlags = selectedTriageFlags,
                    headcount = headcount,
                    language = currentLanguage,
                    onToggleFlag = { viewModel.toggleTriageFlag(it) },
                    onIncrementHeadcount = { viewModel.incrementHeadcount() },
                    onDecrementHeadcount = { viewModel.decrementHeadcount() }
                )

                // Section 5: Acoustic Sub-Debris Rescue Siren & 5s Pre-Vibration Controls
                SirenControlBar(
                    isSirenActive = isSirenActive,
                    isPreVibrating = isPreVibrating,
                    countdownSeconds = countdownSeconds,
                    language = currentLanguage,
                    onStartSiren = { viewModel.startSiren() },
                    onStopSiren = { viewModel.stopSiren() },
                    onCancelPreSiren = { viewModel.cancelPreSiren() },
                    onRescuerWakeTest = { viewModel.triggerRescuerAcousticWake() }
                )

                // Section 6: Adaptive Battery Saver & Deep-Sleep Duty Cycling Card
                BatterySaverToggleCard(
                    isPowerSaver = isPowerSaverMode,
                    sleepIntervalMinutes = sleepIntervalMinutes,
                    dutyCyclePhase = dutyCyclePhase,
                    onToggle = { viewModel.togglePowerSaver() },
                    onConfigureClick = { showSleepConfigSheet = true }
                )

                // Section 7: Store-Carry-Forward Mesh Activity & Ring Buffer
                MeshActivityCard(
                    cachedPacketsCount = cachedPackets.size,
                    relayedPacketsCount = relayedPacketsCount,
                    nearbyNodesCount = nearbyNodesCount,
                    onViewPacketsClick = { showPacketsSheet = true }
                )
            }

            // Bottom Sheets
            if (showSleepConfigSheet) {
                SleepIntervalBottomSheet(
                    currentMinutes = sleepIntervalMinutes,
                    onSelectMinutes = {
                        viewModel.setSleepInterval(it)
                        showSleepConfigSheet = false
                    },
                    onDismiss = { showSleepConfigSheet = false }
                )
            }

            if (showPacketsSheet) {
                MeshPacketsBottomSheet(
                    packets = cachedPackets,
                    onDismiss = { showPacketsSheet = false }
                )
            }
        }
    }
}

/**
 * Triggers tactile haptic feedback (long distinct vibration) upon tapping 1-Tap SOS.
 */
private fun triggerTactileHapticFeedback(context: Context) {
    try {
        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vibratorManager?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator?.vibrate(VibrationEffect.createOneShot(400L, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator?.vibrate(400L)
        }
    } catch (e: Exception) {
        android.util.Log.w("MainActivity", "Haptic feedback unavailable: ${e.message}")
    }
}
