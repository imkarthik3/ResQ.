package com.offgrid.mesh

import java.nio.ByteBuffer
import java.security.SecureRandom
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

object Triage {
    const val MEDICAL = 1
    const val PREGNANT = 2
    const val TRAPPED = 4
    const val FOOD_WATER = 8
    const val CHILD_ELDERLY = 16
}

class MeshPacket(
    val type: Int, val id: ByteArray, val lat: Float, val lon: Float,
    val triage: Int, val headcount: Int, val batteryPct: Int,
    val ttl: Int, val epoch: Long
) {
    val idHex: String get() = id.joinToString("") { "%02x".format(it) }
    val hasFix: Boolean get() = !lat.isNaN() && !lon.isNaN()
}

/**
 * Layout (big-endian), 30 bytes:
 *  0 type | 1-8 id | 9-12 lat f32 | 13-16 lon f32 | 17 triage | 18 headcount<<4 | battery(0-15)
 *  19 TTL | 20-23 epoch (u32) | 24-29 auth (HMAC-SHA256 truncated; TTL byte excluded so relays can decrement it)
 *
 * Legacy (BLE 4.x) advertising only fits 27 payload bytes, so a 27-byte form (3-byte auth) is also accepted.
 */
object PacketSerializer {
    const val TYPE_SOS = 0x01
    const val TYPE_WAKE_SIREN = 0x02
    const val FULL = 30
    const val LEGACY = 27
    const val INITIAL_TTL = 5
    const val MANUFACTURER_ID = 0xFFFF // test/reserved ID: replace before real deployment

    // TODO: provision per deployment (rescuer devices need the same key). A key baked into a public APK
    // is NOT secret - anyone can forge packets. Treat this as a placeholder.
    private val KEY = "CHANGE-ME-provision-per-deployment".toByteArray()
    private val rng = SecureRandom()

    fun newId() = ByteArray(8).also { rng.nextBytes(it) }

    fun encode(
        type: Int, lat: Double, lon: Double, triage: Int, headcount: Int, batteryPct: Int,
        id: ByteArray = newId(), ttl: Int = INITIAL_TTL, epoch: Long = System.currentTimeMillis() / 1000
    ): ByteArray {
        val b = ByteBuffer.allocate(FULL)
        b.put(type.toByte()); b.put(id, 0, 8)
        b.putFloat(lat.toFloat()); b.putFloat(lon.toFloat())
        b.put(triage.toByte())
        b.put(((headcount.coerceIn(0, 15) shl 4) or (batteryPct.coerceIn(0, 100) * 15 / 100)).toByte())
        b.put(ttl.toByte()); b.putInt(epoch.toInt())
        val a = b.array()
        mac(a).copyInto(a, 24, 0, 6)
        return a
    }

    private fun mac(p: ByteArray): ByteArray {
        val c = p.copyOfRange(0, 24); c[19] = 0
        return Mac.getInstance("HmacSHA256").run {
            init(SecretKeySpec(KEY, "HmacSHA256")); doFinal(c)
        }
    }

    fun decode(raw: ByteArray): MeshPacket? {
        if (raw.size != FULL && raw.size != LEGACY) return null
        val authLen = raw.size - 24
        if (!mac(raw).copyOf(authLen).contentEquals(raw.copyOfRange(24, raw.size))) return null
        val b = ByteBuffer.wrap(raw)
        val type = b.get().toInt() and 0xFF
        if (type != TYPE_SOS && type != TYPE_WAKE_SIREN) return null
        val id = ByteArray(8).also { b.get(it) }
        val lat = b.float; val lon = b.float
        val triage = b.get().toInt() and 0xFF
        val hb = b.get().toInt() and 0xFF
        val ttl = b.get().toInt() and 0xFF
        val epoch = b.int.toLong() and 0xFFFFFFFFL
        return MeshPacket(type, id, lat, lon, triage, hb shr 4, (hb and 0x0F) * 100 / 15, ttl, epoch)
    }

    fun withTtl(raw: ByteArray, ttl: Int): ByteArray = raw.copyOf().also { it[19] = ttl.toByte() }
    fun toLegacy(raw: ByteArray): ByteArray = raw.copyOf(minOf(raw.size, LEGACY))

    /** Rescuer-side helper: build an authenticated siren command. */
    fun encodeWakeSiren() = encode(TYPE_WAKE_SIREN, Double.NaN, Double.NaN, 0, 0, 100, ttl = 0)
}
