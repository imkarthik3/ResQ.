package com.offgrid.mesh

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

private val Red = Color(0xFFFF3B30)
private val Amber = Color(0xFFFFB300)
private val Green = Color(0xFF30D158)
private val Bg = Color(0xFF0B0F0C)
private val CardBg = Color(0xFF1A201C)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = CardBg, primary = Red)) {
                Surface(Modifier.fillMaxSize(), color = Bg) { Root() }
            }
        }
    }
}

private fun requiredPerms() = buildList {
    add(Manifest.permission.ACCESS_FINE_LOCATION)
    if (Build.VERSION.SDK_INT >= 31) {
        add(Manifest.permission.BLUETOOTH_SCAN); add(Manifest.permission.BLUETOOTH_ADVERTISE)
        add(Manifest.permission.BLUETOOTH_CONNECT)
    }
    if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
}.toTypedArray()

private fun hasAll(c: Context) = requiredPerms().all {
    ContextCompat.checkSelfPermission(c, it) == PackageManager.PERMISSION_GRANTED
}

private fun send(c: Context, action: String, triage: Int = 0, headcount: Int = 1) =
    ContextCompat.startForegroundService(
        c, Intent(c, BleMeshService::class.java).setAction(action)
            .putExtra(BleMeshService.EXTRA_TRIAGE, triage).putExtra(BleMeshService.EXTRA_HEADCOUNT, headcount)
    )

@Composable
private fun Root() {
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(hasAll(ctx)) }
    val launcher = rememberLauncherForActivityResult(RequestMultiplePermissions()) { granted = hasAll(ctx) }
    LaunchedEffect(granted) { if (granted) send(ctx, BleMeshService.ACTION_START) }
    if (granted) MainScreen() else Explainer { launcher.launch(requiredPerms()) }
}

@Composable
private fun Explainer(onAllow: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Card(colors = CardDefaults.cardColors(containerColor = CardBg), shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Text("🆘 Help can find you", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                Text(
                    "To send your SOS with no internet, this app needs:\n\n" +
                        "📍 Location – so rescuers know where you are (works in Airplane Mode).\n\n" +
                        "📡 Nearby devices (Bluetooth) – to pass your SOS to phones around you.\n\n" +
                        "🔔 Notifications – so the app can keep running with the screen off.",
                    fontSize = 18.sp, color = Color.White
                )
                Button(
                    onClick = onAllow, modifier = Modifier.fillMaxWidth().height(72.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Color.Black)
                ) { Text("ALLOW & GET READY", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold) }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun MainScreen() {
    val ctx = LocalContext.current
    val gps by MeshState.gpsFixed.collectAsState()
    val sats by MeshState.satellites.collectAsState()
    val ble by MeshState.bleActive.collectAsState()
    val batt by MeshState.battery.collectAsState()
    val saver by MeshState.powerSaver.collectAsState()
    val sleepMin by MeshState.sleepMinutes.collectAsState()
    val lowAlert by MeshState.lowBatteryAlert.collectAsState()
    val sos by MeshState.sosActive.collectAsState()
    val siren by MeshState.sirenActive.collectAsState()

    var triage by rememberSaveable { mutableIntStateOf(0) }
    var headcount by rememberSaveable { mutableIntStateOf(1) }
    var note by rememberSaveable { mutableStateOf("") } // shown locally only: the 30-byte packet has no room for text

    // Live-update the broadcast when the victim edits chips/headcount after pressing SOS.
    LaunchedEffect(triage, headcount) { if (sos) send(ctx, BleMeshService.ACTION_SOS, triage, headcount) }

    Column(Modifier.fillMaxSize().systemBarsPadding().padding(12.dp)) {
        // Top ~40%: read-only status
        Column(Modifier.weight(0.4f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Card(colors = CardDefaults.cardColors(containerColor = CardBg), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    StatusLine(if (gps) "GPS Fixed (Satellites: $sats)" else "Searching GPS… go outdoors / near a window", if (gps) Green else Amber)
                    StatusLine(if (ble) "BLE Broadcasting Active" else "BLE Deep Sleep (wakes automatically)", if (ble) Green else Amber)
                    val d = MeshState.daysLeft(batt, saver)
                    StatusLine("Battery $batt%  ·  Life Estimate: ~${"%.1f".format(d)} Days", if (batt >= 60) Green else if (batt >= 20) Amber else Red)
                }
            }
            if (lowAlert) Card(colors = CardDefaults.cardColors(containerColor = Amber), shape = RoundedCornerShape(16.dp)) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("🔋 Battery below 60% — Power Saver Mesh Mode is now ON to keep your SOS alive longer.",
                        color = Color.Black, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    TextButton(onClick = { MeshState.lowBatteryAlert.value = false }) { Text("OK", color = Color.Black, fontWeight = FontWeight.ExtraBold) }
                }
            }
        }

        // Bottom ~60%: everything you tap, reachable with one thumb
        Column(
            Modifier.weight(0.6f).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp), horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (siren) Button(
                onClick = { send(ctx, BleMeshService.ACTION_STOP_SIREN) },
                modifier = Modifier.fillMaxWidth().height(84.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Color.Black)
            ) { Text("I AM SAFE / STOP SIREN", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold) }

            SosButton(sos) { send(ctx, BleMeshService.ACTION_SOS, triage, headcount) }
            if (sos) TextButton(onClick = { send(ctx, BleMeshService.ACTION_CANCEL_SOS) }) {
                Text("Cancel my SOS", fontSize = 18.sp, color = Color.White)
            }

            FlowRow(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp), maxItemsInEachRow = 2) {
                listOf(
                    Triple("🩺", "Injured / Medical Urgent", Triage.MEDICAL),
                    Triple("🤰", "Pregnant Lady", Triage.PREGNANT),
                    Triple("🧱", "Trapped Under Debris", Triage.TRAPPED),
                    Triple("💧", "Need Food & Clean Water", Triage.FOOD_WATER),
                    Triple("👶", "Children / Elderly Present", Triage.CHILD_ELDERLY),
                ).forEach { (icon, label, bit) ->
                    val on = triage and bit != 0
                    Surface(
                        modifier = Modifier.weight(1f).heightIn(min = 72.dp).clickable { triage = triage xor bit },
                        shape = RoundedCornerShape(16.dp), color = CardBg,
                        border = BorderStroke(if (on) 4.dp else 1.dp, if (on) Amber else Color.DarkGray)
                    ) {
                        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(icon, fontSize = 28.sp); Spacer(Modifier.width(8.dp))
                            Text(label, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                StepButton("−") { if (headcount > 1) headcount-- }
                Text("$headcount ${if (headcount == 1) "Person" else "Persons"}", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                StepButton("+") { if (headcount < 15) headcount++ }
            }

            OutlinedTextField(
                value = note, onValueChange = { note = it }, modifier = Modifier.fillMaxWidth(), maxLines = 3,
                placeholder = { Text("Optional: Landmark or specific injury details...") },
                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 18.sp)
            )

            Card(colors = CardDefaults.cardColors(containerColor = CardBg), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Power Saver Mesh Mode", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = Color.White, modifier = Modifier.weight(1f))
                        Switch(checked = saver, onCheckedChange = { MeshState.powerSaver.value = it }, modifier = Modifier.scale(1.4f))
                    }
                    Text("Uses much less battery while keeping your SOS active in the background.", fontSize = 15.sp, color = Color.LightGray)
                    if (saver) {
                        Text("Sleep between bursts:", fontSize = 15.sp, color = Color.LightGray)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(5, 15, 30).forEach { m ->
                                FilterChip(selected = sleepMin == m, onClick = { MeshState.sleepMinutes.value = m },
                                    label = { Text("$m min", fontSize = 18.sp, modifier = Modifier.padding(vertical = 10.dp)) })
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun StatusLine(text: String, color: Color) = Row(verticalAlignment = Alignment.CenterVertically) {
    Box(Modifier.size(14.dp).background(color, CircleShape)); Spacer(Modifier.width(10.dp))
    Text(text, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Color.White)
}

@Composable
private fun StepButton(label: String, onClick: () -> Unit) =
    Button(onClick = onClick, modifier = Modifier.size(72.dp), shape = CircleShape, contentPadding = PaddingValues(0.dp),
        colors = ButtonDefaults.buttonColors(containerColor = CardBg, contentColor = Color.White),
        border = BorderStroke(2.dp, Color.Gray)) { Text(label, fontSize = 36.sp, fontWeight = FontWeight.ExtraBold) }

@Composable
private fun SosButton(active: Boolean, onClick: () -> Unit) {
    val t = rememberInfiniteTransition(label = "pulse")
    val scale by t.animateFloat(1f, 1.4f, infiniteRepeatable(tween(1300, easing = LinearEasing)), label = "s")
    val alpha by t.animateFloat(0.6f, 0f, infiniteRepeatable(tween(1300, easing = LinearEasing)), label = "a")
    val color = if (active) Green else Red
    Box(Modifier.size(260.dp), contentAlignment = Alignment.Center) {
        Box(Modifier.size(190.dp).scale(scale).alpha(alpha).background(color, CircleShape))
        Box(
            Modifier.size(190.dp).clip(CircleShape).background(color).clickable(onClick = onClick)
                .semantics { contentDescription = "Send SOS" },
            contentAlignment = Alignment.Center
        ) {
            Text(if (active) "SOS\nACTIVE" else "SOS", fontSize = if (active) 34.sp else 52.sp, fontWeight = FontWeight.ExtraBold,
                textAlign = TextAlign.Center, color = if (active) Color.Black else Color.White)
        }
    }
}
