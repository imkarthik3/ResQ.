package com.offgrid.mesh

import android.app.NotificationManager
import android.content.Context
import android.media.*
import kotlinx.coroutines.*
import kotlin.math.PI
import kotlin.math.sin

/**
 * Loud intermittent wail on STREAM_ALARM (USAGE_ALARM), volume forced to max.
 * Alarms play through Silent and normal Do Not Disturb. They are only blocked by "Total silence" DND,
 * which no app can bypass without the user granting Notification Policy access - see [needsDndAccess].
 */
object SirenManager {
    private var job: Job? = null
    private var track: AudioTrack? = null
    private var prevVolume = -1

    fun needsDndAccess(ctx: Context) =
        !ctx.getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted

    fun start(ctx: Context) {
        if (job?.isActive == true) return
        val am = ctx.getSystemService(AudioManager::class.java)
        prevVolume = am.getStreamVolume(AudioManager.STREAM_ALARM)
        am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)

        val rate = 22050
        val pcm = wail(rate, seconds = 3)
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            )
            .setAudioFormat(
                AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
            )
            .setTransferMode(AudioTrack.MODE_STATIC)
            .setBufferSizeInBytes(pcm.size * 2).build()
        t.write(pcm, 0, pcm.size)
        track = t
        job = CoroutineScope(Dispatchers.Default).launch {
            while (isActive) {
                t.reloadStaticData(); t.play()
                delay(3000); t.stop()
                delay(1200) // intermittent: pause so rescuers can also listen for calls
            }
        }
    }

    fun stop(ctx: Context) {
        job?.cancel(); job = null
        track?.run { runCatching { stop() }; release() }; track = null
        if (prevVolume >= 0) {
            ctx.getSystemService(AudioManager::class.java).setStreamVolume(AudioManager.STREAM_ALARM, prevVolume, 0)
            prevVolume = -1
        }
    }

    /** 800 -> 1800 Hz rising wail, repeated. */
    private fun wail(rate: Int, seconds: Int): ShortArray {
        val out = ShortArray(rate * seconds)
        var phase = 0.0
        val sweep = rate // 1 s per sweep
        for (i in out.indices) {
            val f = 800.0 + 1000.0 * ((i % sweep).toDouble() / sweep)
            phase += 2 * PI * f / rate
            out[i] = (sin(phase) * 0.95 * Short.MAX_VALUE).toInt().toShort()
        }
        return out
    }
}
