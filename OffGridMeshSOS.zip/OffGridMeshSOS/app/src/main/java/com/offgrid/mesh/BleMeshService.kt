package com.offgrid.mesh

import android.Manifest
import android.annotation.SuppressLint
import android.app.*
import android.bluetooth.BluetoothManager
import android.bluetooth.le.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.*
import android.os.*
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlin.math.abs

/** Shared UI <-> service state. */
object MeshState {
    val gpsFixed = MutableStateFlow(false)
    val satellites = MutableStateFlow(0)
    val bleActive = MutableStateFlow(false)
    val battery = MutableStateFlow(100)
    val powerSaver = MutableStateFlow(false)
    val sleepMinutes = MutableStateFlow(15)
    val lowBatteryAlert = MutableStateFlow(false)
    val sosActive = MutableStateFlow(false)
    val sirenActive = MutableStateFlow(false)
    val relayedCount = MutableStateFlow(0)

    /** Rough estimate assuming a ~4000 mAh battery and ~30 mA (normal) / ~5 mA (saver) average draw. */
    fun daysLeft(pct: Int, saver: Boolean) = pct / 100.0 * 4000 / (if (saver) 5.0 else 30.0) / 24
}

class BleMeshService : Service() {
    companion object {
        const val ACTION_START = "mesh.START"
        const val ACTION_SOS = "mesh.SOS"
        const val ACTION_CANCEL_SOS = "mesh.CANCEL_SOS"
        const val ACTION_STOP_SIREN = "mesh.STOP_SIREN"
        const val EXTRA_TRIAGE = "triage"
        const val EXTRA_HEADCOUNT = "headcount"
        private const val ACTIVE_WINDOW_MS = 30_000L
        private const val DWELL_MS = 4_000L
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val dao by lazy { EmergencyDatabase.get(this).dao() }
    private val adapter by lazy { getSystemService(BluetoothManager::class.java).adapter }
    private val lm by lazy { getSystemService(LocationManager::class.java) }
    private var wakeLock: PowerManager.WakeLock? = null
    private var loop: Job? = null
    private var lastLoc: Location? = null
    private var lastBuiltLoc: Location? = null
    private var lastBuildAt = 0L
    private var triage = 0
    private var headcount = 1
    private var autoSaverHandled = false
    private var scanning = false
    private var scanMode = -1
    private var advSet: AdvertisingSetCallback? = null
    private var advLegacy: AdvertiseCallback? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!hasPerms()) { stopSelf(); return START_NOT_STICKY }
        goForeground()
        if (wakeLock == null) {
            wakeLock = getSystemService(PowerManager::class.java)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "mesh:ble")
                .apply { acquire(3 * 24 * 3600 * 1000L) }
            startLocation()
        }
        when (intent?.action) {
            ACTION_SOS -> {
                triage = intent.getIntExtra(EXTRA_TRIAGE, 0)
                headcount = intent.getIntExtra(EXTRA_HEADCOUNT, 1)
                MeshState.sosActive.value = true
                scope.launch { rebuildOwn() }
            }
            ACTION_CANCEL_SOS -> { MeshState.sosActive.value = false; scope.launch { dao.clearOwn() } }
            ACTION_STOP_SIREN -> { SirenManager.stop(this); MeshState.sirenActive.value = false }
        }
        startLoop()
        return START_STICKY
    }

    // ---------- duty cycle ----------
    private fun startLoop() {
        if (loop?.isActive == true) return
        loop = scope.launch {
            while (isActive) {
                refreshBattery()
                if (MeshState.sosActive.value && System.currentTimeMillis() - lastBuildAt > 10 * 60_000L) rebuildOwn()
                if (!MeshState.powerSaver.value) {
                    MeshState.bleActive.value = true
                    startScan(ScanSettings.SCAN_MODE_LOW_POWER)
                    broadcastRound()
                } else {
                    // 30 s active, then deep sleep (radios fully off) with jitter so two phones on the
                    // same schedule don't stay permanently out of phase.
                    MeshState.bleActive.value = true
                    startScan(ScanSettings.SCAN_MODE_BALANCED)
                    val end = System.currentTimeMillis() + ACTIVE_WINDOW_MS
                    while (isActive && System.currentTimeMillis() < end && MeshState.powerSaver.value) broadcastRound()
                    stopScan(); stopAdvertise()
                    MeshState.bleActive.value = false
                    val sleep = MeshState.sleepMinutes.value * 60_000L
                    delay((sleep * (0.9 + Math.random() * 0.2)).toLong())
                }
            }
        }
    }

    /** Rotate own SOS + cached packets, one at a time. */
    private suspend fun broadcastRound() {
        val list = listOfNotNull(dao.own()) + dao.relayable(4)
        if (list.isEmpty()) { delay(DWELL_MS); return }
        for (p in list) {
            advertise(p.raw)
            delay(DWELL_MS)
            if (!p.own) dao.markSent(p.id, System.currentTimeMillis())
        }
        stopAdvertise()
    }

    // ---------- BLE ----------
    @SuppressLint("MissingPermission")
    private fun advertise(raw: ByteArray) {
        stopAdvertise()
        val adv = adapter?.bluetoothLeAdvertiser ?: return
        val extended = Build.VERSION.SDK_INT >= 26 && adapter.isLeExtendedAdvertisingSupported
        // Legacy advertising carries at most 27 manufacturer bytes (31 - 4 header), so 30 bytes need BLE 5 extended adv.
        val data = AdvertiseData.Builder().setIncludeDeviceName(false)
            .addManufacturerData(PacketSerializer.MANUFACTURER_ID, if (extended) raw else PacketSerializer.toLegacy(raw))
            .build()
        if (extended) {
            val params = AdvertisingSetParameters.Builder().setLegacyMode(false).setConnectable(false)
                .setScannable(false).setInterval(AdvertisingSetParameters.INTERVAL_MEDIUM)
                .setTxPowerLevel(AdvertisingSetParameters.TX_POWER_HIGH).build()
            val cb = object : AdvertisingSetCallback() {}
            advSet = cb
            adv.startAdvertisingSet(params, data, null, null, null, cb)
        } else {
            val settings = AdvertiseSettings.Builder()
                .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_POWER)
                .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_HIGH)
                .setConnectable(false).setTimeout(0).build()
            val cb = object : AdvertiseCallback() {}
            advLegacy = cb
            adv.startAdvertising(settings, data, cb)
        }
    }

    @SuppressLint("MissingPermission")
    private fun stopAdvertise() {
        val adv = adapter?.bluetoothLeAdvertiser ?: return
        advSet?.let { runCatching { adv.stopAdvertisingSet(it) } }; advSet = null
        advLegacy?.let { runCatching { adv.stopAdvertising(it) } }; advLegacy = null
    }

    private val scanCb = object : ScanCallback() {
        override fun onScanResult(type: Int, r: ScanResult) {
            val raw = r.scanRecord?.getManufacturerSpecificData(PacketSerializer.MANUFACTURER_ID) ?: return
            scope.launch { onReceive(raw) }
        }
    }

    @SuppressLint("MissingPermission")
    private fun startScan(mode: Int) {
        if (scanning && mode == scanMode) return
        stopScan(); scanMode = mode
        val scanner = adapter?.bluetoothLeScanner ?: return
        val filter = ScanFilter.Builder().setManufacturerData(PacketSerializer.MANUFACTURER_ID, ByteArray(0)).build()
        val s = ScanSettings.Builder().setScanMode(mode).apply {
            if (Build.VERSION.SDK_INT >= 26) setLegacy(false) // also receive 30-byte extended adverts
        }.build()
        scanner.startScan(listOf(filter), s, scanCb); scanning = true
    }

    @SuppressLint("MissingPermission")
    private fun stopScan() {
        if (!scanning) return
        runCatching { adapter?.bluetoothLeScanner?.stopScan(scanCb) }; scanning = false
    }

    private suspend fun onReceive(raw: ByteArray) {
        val p = PacketSerializer.decode(raw) ?: return         // bad size / bad auth -> drop
        if (dao.own()?.id == p.idHex) return
        val isWake = p.type == PacketSerializer.TYPE_WAKE_SIREN
        val ttl = if (isWake) 0 else p.ttl - 1                  // siren commands are stored for dedup only, never relayed
        val fresh = dao.insert(PacketEntity(p.idHex, PacketSerializer.withTtl(raw, ttl), ttl, false, System.currentTimeMillis())) != -1L
        if (!fresh) return
        dao.trim()
        if (isWake) {
            // Replay guard: ignore commands older than 24 h.
            if (abs(System.currentTimeMillis() / 1000 - p.epoch) < 86_400) {
                SirenManager.start(this); MeshState.sirenActive.value = true
            }
        } else MeshState.relayedCount.update { it + 1 }
    }

    // ---------- own SOS packet ----------
    @SuppressLint("MissingPermission")
    private suspend fun rebuildOwn() {
        val loc = lastLoc ?: lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
        val raw = PacketSerializer.encode(
            PacketSerializer.TYPE_SOS,
            loc?.latitude ?: Double.NaN, loc?.longitude ?: Double.NaN,
            triage, headcount, MeshState.battery.value
        )
        val p = PacketSerializer.decode(raw)!!
        dao.clearOwn()
        dao.insert(PacketEntity(p.idHex, raw, p.ttl, true, System.currentTimeMillis()))
        lastBuiltLoc = loc; lastBuildAt = System.currentTimeMillis()
    }

    // ---------- GPS (works in airplane mode) ----------
    @SuppressLint("MissingPermission")
    private fun startLocation() {
        lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 10_000L, 0f, locListener, Looper.getMainLooper())
        lm.registerGnssStatusCallback(gnssCb, Handler(Looper.getMainLooper()))
    }

    private val locListener = LocationListener { loc ->
        lastLoc = loc; MeshState.gpsFixed.value = true
        val moved = lastBuiltLoc?.distanceTo(loc) ?: Float.MAX_VALUE
        if (MeshState.sosActive.value && moved > 30f) scope.launch { rebuildOwn() }
    }

    private val gnssCb = object : GnssStatus.Callback() {
        override fun onSatelliteStatusChanged(s: GnssStatus) {
            MeshState.satellites.value = (0 until s.satelliteCount).count { s.usedInFix(it) }
            if (MeshState.satellites.value == 0) MeshState.gpsFixed.value = false
        }
    }

    // ---------- battery ----------
    private fun refreshBattery() {
        val pct = getSystemService(BatteryManager::class.java).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        MeshState.battery.value = pct
        if (pct < 60 && !autoSaverHandled) {
            autoSaverHandled = true
            if (!MeshState.powerSaver.value) { MeshState.powerSaver.value = true; MeshState.lowBatteryAlert.value = true }
        } else if (pct >= 65) autoSaverHandled = false
    }

    // ---------- plumbing ----------
    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("mesh", "Mesh SOS", NotificationManager.IMPORTANCE_LOW))
        val n = NotificationCompat.Builder(this, "mesh")
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("Mesh SOS is running")
            .setContentText("Listening for and relaying emergency signals")
            .setContentIntent(PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
            .setOngoing(true).build()
        val type = if (Build.VERSION.SDK_INT >= 29)
            ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE or ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION else 0
        ServiceCompat.startForeground(this, 1, n, type)
    }

    private fun hasPerms(): Boolean {
        val need = buildList {
            add(Manifest.permission.ACCESS_FINE_LOCATION)
            if (Build.VERSION.SDK_INT >= 31) {
                add(Manifest.permission.BLUETOOTH_SCAN); add(Manifest.permission.BLUETOOTH_ADVERTISE)
                add(Manifest.permission.BLUETOOTH_CONNECT)
            }
        }
        return need.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }
    }

    @SuppressLint("MissingPermission")
    override fun onDestroy() {
        scope.cancel(); stopScan(); stopAdvertise()
        runCatching { lm.removeUpdates(locListener); lm.unregisterGnssStatusCallback(gnssCb) }
        SirenManager.stop(this); MeshState.sirenActive.value = false
        wakeLock?.takeIf { it.isHeld }?.release()
        super.onDestroy()
    }
}
