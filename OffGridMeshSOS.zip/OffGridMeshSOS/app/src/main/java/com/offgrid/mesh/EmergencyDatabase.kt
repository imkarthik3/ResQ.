package com.offgrid.mesh

import android.content.Context
import androidx.room.*

@Entity(tableName = "packets")
data class PacketEntity(
    @PrimaryKey val id: String,          // 8-byte packet hash as hex (dedup key)
    val raw: ByteArray,                  // wire bytes (TTL already decremented for received packets)
    val ttl: Int,
    val own: Boolean,
    val receivedAt: Long,
    val lastSentAt: Long = 0
)

@Dao
interface PacketDao {
    /** Returns -1 if the id already exists (= duplicate). */
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(p: PacketEntity): Long

    @Query("SELECT * FROM packets WHERE own = 1 LIMIT 1")
    suspend fun own(): PacketEntity?

    @Query("DELETE FROM packets WHERE own = 1")
    suspend fun clearOwn()

    /** Least-recently-sent first, so every cached packet gets airtime. */
    @Query("SELECT * FROM packets WHERE own = 0 AND ttl > 0 ORDER BY lastSentAt ASC LIMIT :n")
    suspend fun relayable(n: Int): List<PacketEntity>

    @Query("UPDATE packets SET lastSentAt = :t WHERE id = :id")
    suspend fun markSent(id: String, t: Long)

    /** Ring buffer: keep only the newest [keep] relayed packets. */
    @Query("DELETE FROM packets WHERE own = 0 AND id NOT IN (SELECT id FROM packets WHERE own = 0 ORDER BY receivedAt DESC LIMIT :keep)")
    suspend fun trim(keep: Int = 200)
}

@Database(entities = [PacketEntity::class], version = 1, exportSchema = false)
abstract class EmergencyDatabase : RoomDatabase() {
    abstract fun dao(): PacketDao

    companion object {
        @Volatile private var inst: EmergencyDatabase? = null
        fun get(ctx: Context): EmergencyDatabase = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, EmergencyDatabase::class.java, "mesh.db")
                .build().also { inst = it }
        }
    }
}
